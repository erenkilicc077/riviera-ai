<p align="center"><img src="docs/assets/cover.svg" alt="Riviera AI — Hotel Guest Intelligence" width="100%"></p>

<h1 align="center">Riviera AI</h1>
<p align="center"><strong>From multilingual guest feedback to actionable hotel operations.</strong></p>
<p align="center">Python · NLP · Logistic Regression · XGBoost · Deep Learning · FastAPI · SQLite</p>

Riviera AI is a working, local-first NLP portfolio project inspired by hotel operations in Antalya, Türkiye. It predicts a review's sentiment and dominant topic, proposes an accountable department through explicit business rules, and lets a team track the follow-up.

**Start in Turkish:** [START_HERE_TR.md](START_HERE_TR.md) · [Technical explanation & interview guide](docs/ANLATIM_REHBERI_TR.md)

> **Data honesty:** the bundled training data, challenge set and seeded dashboard reviews are synthetic and AI-authored. No real hotel ratings, customer identities or commercial results are represented. The project is a learning prototype, not a validated production system.

## What you can actually do

- Analyze Turkish, English, German and Russian text using locally trained models; no API keys.
- Compare **TF-IDF + logistic regression**, **SVD + XGBoost**, and a **two-hidden-layer, multi-task neural network** on the same splits.
- Inspect real neural-network code: ReLU, two softmax heads, cross-entropy, backpropagation, Adam, L2 and validation early stopping, implemented with NumPy.
- Open an offline-friendly Turkish dashboard with district/date filters, sentiment trends, topic counts and a paginated review inbox.
- Save analyses to SQLite, assign a follow-up status, import UTF-8 CSV, and export a spreadsheet-safe CSV.
- Examine transparent routing rules and a heuristic human-review flag. These are clearly separated from learned model predictions.
- Read reproducible reports, inspect mistakes in `reports/challenge_predictions.csv`, and rerun tests and training.

## Run in five minutes after dependency installation

Python **3.12 recommended**; 3.11+ supported. Run these commands **inside this repository folder**.

```bash
python -m venv .venv
```

Activate the environment:

```powershell
# Windows PowerShell
.venv\Scripts\Activate.ps1
```

```bash
# macOS / Linux
source .venv/bin/activate
```

Then:

```bash
python -m pip install -e ".[dev]"
python run.py --demo
```

Open **http://127.0.0.1:8000**. Interactive API docs: **http://127.0.0.1:8000/docs**.

The ZIP includes trained artifacts. `--demo` inserts 96 explicitly synthetic reviews; re-running on the same date skips duplicates. Omit `--demo` for an empty workspace. The first dependency installation needs internet; inference has no external service calls. Installation time depends on the connection and platform.

For the exact dependency versions used to produce the included artifacts:

```bash
python -m pip install -r requirements-lock.txt
python -m pip install -e . --no-deps
```

Model pickle files are version-sensitive. If your scikit-learn version differs from `models/metadata.json`, regenerate the artifacts before running. Only load model files you trust.

## A useful first demo

1. Open **AI laboratuvarı**, select a language sample, and click **Analiz et**.
2. Try **3 modeli karşılaştır** and inspect disagreements and score differences.
3. Save one review, open **Yorum kutusu**, and change its status to **Çözüldü**.
4. Return to **Genel bakış**: the open-complaint metric changes only for an accepted negative review.
5. Import `data/import_template.csv`, then export the filtered results.
6. Open **Model karşılaştırması**. Compare easy template-test scores with the separate 48-example challenge set.

## Why these models?

| Candidate | Input | Learned model | Purpose |
| --- | --- | --- | --- |
| `logreg` | Word + character TF-IDF | Separate logistic classifiers for sentiment/topic | Strong, inspectable text baseline |
| `xgboost` | Train-fitted TF-IDF → 96-component SVD → standardization | Separate boosted-tree classifiers | Nonlinear tree-ensemble comparison |
| `neural_mlp` | Same train-fitted dense features | Shared 96 → 96 → 48 ReLU backbone; 3-way + 8-way softmax heads | Inspectable multi-task deep-learning experiment |

The neural network is a **real trainable dense network**, not a Transformer, LLM or rule-based sentiment classifier. The project deliberately exposes the math rather than hiding it behind a large framework. It uses no pretrained language-model weights. See [the model card](docs/MODEL_CARD.md).

The best mean **validation** macro-F1 across the two tasks selects the default serving model. No test or challenge scores choose the model. A more complex model is allowed to lose.

## Reproduce the experiment

```bash
python -m riviera.dataset
python -m riviera.train
python -m riviera.evaluate
python -m pytest -q
```

The first command regenerates the bundled synthetic dataset deterministically. Skip it when using a separately prepared labeled dataset. Training fits the vectorizers, SVD and scaler on **train only**. Neural early stopping uses validation loss. The evaluator adds the independent challenge results to model metadata and saves every challenge prediction for inspection.

See [actual included benchmark results](reports/BENCHMARK.md), [data provenance](docs/DATA_CARD.md) and [model limitations](docs/MODEL_CARD.md). All reported F1 scores before rejection include candidate labels flagged for human review.

![Neural learning curve](reports/learning_curve.png)

## Architecture

```mermaid
flowchart TD
    UI["Turkish dashboard"] --> API["FastAPI / Pydantic"]
    API --> Service["Application service"]
    Service --> Engine["Review inference engine"]
    Service --> DB["SQLite repository"]
    Engine --> Linear["TF-IDF + logistic regression"]
    Engine --> Trees["SVD + XGBoost"]
    Engine --> Neural["Multi-task neural network"]
    Engine --> Rules["Explicit routing and review rules"]
```

Read [design decisions and scaling trade-offs](docs/ARCHITECTURE.md). The local demo uses one application and one database; queues, microservices and Kubernetes would add unjustified complexity at this scale.

## Repository map

```text
riviera/                    Core Python package
  dataset.py                Deterministic synthetic generator + leakage checks
  train.py                  Preprocessing, model fitting, validation selection, test reporting
  neural.py                 NumPy multi-task MLP, backprop and Adam
  evaluate.py               Separate challenge evaluation
  inference.py              Serving, score reporting and review gate
  schemas.py                API input validation
  service.py                Batch validation / orchestration
  store.py                  SQLite persistence and aggregates
  api.py                    REST endpoints
  web/                      Self-contained HTML / CSS / JavaScript dashboard
data/                       Synthetic corpus, challenge corpus and CSV template
models/                     Trained artifacts + metadata
reports/                    Actual metrics, errors and plots
notebooks/                  Walkthrough notebook
tests/                      Leakage, gradient, persistence and API tests
docs/                       Turkish explanation + engineering documentation
scripts/                    Real-data preparation and container entrypoint
```

## API example

```bash
curl -X POST http://127.0.0.1:8000/api/predict \
  -H "Content-Type: application/json" \
  -d '{"text":"The breakfast buffet was excellent.","model":"auto"}'
```

| Endpoint | Purpose |
| --- | --- |
| `GET /api/health` | Readiness / version |
| `GET /api/models` | Training provenance and actual benchmarks |
| `POST /api/predict` | One review, optional model selection |
| `POST /api/predict/batch` | Up to 100 texts |
| `POST /api/reviews` | Predict and persist a review |
| `GET /api/reviews` | District/date/sentiment/status filters + pagination |
| `POST /api/reviews/import` | Validate all rows, then commit up to 500 CSV records |
| `PATCH /api/reviews/{id}/status` | Human-managed follow-up state |
| `GET /api/dashboard` | Metrics computed from persisted predictions |
| `GET /api/export` | Filtered UTF-8 CSV, maximum 10,000 rows |

Scores are **uncalibrated model outputs**, not verified confidence. Low scores or sparse known-word coverage trigger a heuristic review flag. This gate is not a proven out-of-distribution detector. Language is caller-supplied metadata; no automatic language detection is claimed.

## Docker

```bash
docker build -t riviera-ai .
docker run --rm -p 127.0.0.1:8000:8000 -e RIVIERA_SEED_DEMO=1 -v riviera-data:/app/runtime riviera-ai
```

Docker configuration is included; local Python execution and browser/API checks are the verified run path. See `reports/VALIDATION.md` for the checks actually performed. The local application has no user authentication or tenant isolation; add those before exposing it publicly or connecting real hotel data.

## Extend with real hotel data

Use authorized, minimized, labeled exports. Do not scrape review platforms by default. See [REAL_DATA.md](docs/REAL_DATA.md) for the schema, group-aware splitting, consent/access requirements and an honest pilot evaluation plan.

## Learning and authorship

Created as an AI-assisted educational starting point for **Eren Kılıç**, Management Information Systems, Akdeniz University. The project should be studied, modified and validated before presenting it as personal independent work. A suggested disclosure and a practical modification checklist are in the Turkish guide.

MIT-licensed project code. Synthetic data is released under [CC0](data/LICENSE.txt). Third-party dependencies retain their own licenses. See [official learning references](docs/REFERENCES.md).
