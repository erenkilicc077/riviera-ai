"""Start the local demo: python run.py --demo"""

import argparse

def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--demo", action="store_true", help="Seed 96 synthetic reviews (idempotent for a given day).")
    parser.add_argument("--port", type=int, default=8000)
    args = parser.parse_args()
    try:
        import uvicorn
        from riviera.config import ROOT
        from riviera.inference import ReviewEngine
        from riviera.service import seed_demo
        from riviera.store import ReviewStore
    except ImportError as exc:
        raise SystemExit(f"Install dependencies first: python -m pip install -e '.[dev]'\n{exc}") from exc
    if not (ROOT / "models/metadata.json").exists():
        raise SystemExit("Train models first: python -m riviera.train")
    if args.demo:
        import os
        store = ReviewStore(os.getenv("RIVIERA_DB_PATH", ROOT / "runtime/reviews.sqlite"))
        result = seed_demo(store, ReviewEngine())
        print(f"Synthetic demo: {result['inserted']} inserted, {result['duplicates']} duplicates skipped.")
    print(f"Riviera AI: http://127.0.0.1:{args.port} | API docs: http://127.0.0.1:{args.port}/docs")
    uvicorn.run("riviera.api:app", host="127.0.0.1", port=args.port)


if __name__ == "__main__":
    main()
