# Eren, buradan başla

Bu proje **Riviera AI**: Antalya'daki otellerin farklı dillerdeki müşteri yorumlarını duygu ve konu açısından analiz eden, ilgili departmana öneri veren bir portfolyo uygulaması.

İçinde gerçek eğitim kodu, eğitilmiş modeller, çalışan panel, API, SQL veritabanı, karşılaştırma raporları ve testler var. Veriler **yapay olarak oluşturulmuştur**. Gerçek bir otelde kullanıldığı veya ticari sonuç sağladığı iddia edilmez.

## 1. Dosyaları aç

ZIP'i bilgisayarında çıkart. VS Code → **File → Open Folder** üzerinden `riviera-ai` klasörünü aç. Klasörün doğrudan içinde `run.py`, `README.md` ve `pyproject.toml` bulunmalı.

Bu adımlar bilgisayarda uygulanır. Telefon üzerinden dosyaları inceleyebilirsin; Python sunucusunu çalıştırmak için bilgisayar veya uygun bir geliştirme ortamı kullan.

## 2. Python'u kontrol et

VS Code'da **Terminal → New Terminal** aç:

```bash
python --version
```

Python 3.12 önerilir; en az 3.11 gerekir. Windows'ta `python` bulunamazsa `py --version` dene ve aşağıdaki ilk komutta `python` yerine `py` yaz.

## 3. Kur ve başlat

Windows PowerShell:

```powershell
python -m venv .venv
.venv\Scripts\python.exe -m pip install -e ".[dev]"
.venv\Scripts\python.exe run.py --demo
```

Bu biçim sanal ortamı etkinleştirme gerektirmez. PowerShell yürütme politikası değiştirmene gerek yoktur.

macOS / Linux:

```bash
python3 -m venv .venv
.venv/bin/python -m pip install -e ".[dev]"
.venv/bin/python run.py --demo
```

İlk kurulumda paketler internetten indirilir; birkaç dakika veya bağlantıya göre daha uzun sürebilir. Sonrasında tarayıcıda **http://127.0.0.1:8000** adresini aç. Terminal açık kalmalı. Kapatmak için **Ctrl+C** kullan.

Modeller pakette hazırdır. Uygulama gerçek yorum sitelerine bağlanmaz ve ücretli API anahtarı istemez.

## 4. İlk gösterimi yap

1. **Genel bakış:** yorum sayısı, olumsuz yorum oranı ve açık şikâyetleri incele. Başlangıçtaki 96 yorum sentetiktir.
2. **AI laboratuvarı:** TR örneğine bas, **Analiz et** seç.
3. **3 modeli karşılaştır:** aynı yorumda modellerin neden farklı sonuç verdiğine bak.
4. **Yorum kutusuna kaydet:** daha sonra **Yorum kutusu** bölümünde kaydı bul.
5. Negatif ve insan incelemesi gerektirmeyen bir kaydı **Çözüldü** yap; genel bakıştaki açık şikâyet sayısını kontrol et.
6. **Model karşılaştırması:** şablonlu test ile ayrı yazılmış 48 örneklik mini sınama arasındaki farkı incele.

## 5. Kod kısmı nerede?

| Merak ettiğin şey | Açacağın dosya |
| --- | --- |
| Veri nasıl oluşturuluyor, sızıntı nasıl engelleniyor? | `riviera/dataset.py` |
| TF-IDF, XGBoost ve model seçimi | `riviera/train.py` |
| Deep learning, geri yayılım, Adam | `riviera/neural.py` |
| Yeni yorum nasıl tahmin ediliyor? | `riviera/inference.py` |
| İlgili departman nasıl belirleniyor? | `riviera/config.py`, `riviera/inference.py` |
| REST API | `riviera/api.py` |
| SQL ve kayıtlar | `riviera/store.py` |
| Panelin tasarımı ve davranışı | `riviera/web/` |
| Model sonuçları ve örnek hatalar | `reports/` |
| Sunum ve mülakat anlatımı | `docs/ANLATIM_REHBERI_TR.md` |

## 6. Modelleri kendin yeniden eğit

Windows'ta aşağıdaki `python` yerine `.venv\Scripts\python.exe`, macOS/Linux'ta `.venv/bin/python` kullanabilirsin:

```bash
python -m riviera.train
python -m riviera.evaluate
python -m pytest -q
```

`train` eğitim, doğrulama ve test raporlarını oluşturur. `evaluate` ayrıca yazılmış mini sınama setini çalıştırır. `pytest` testleri çalıştırır. Her yeniden eğitim sonrası uygulamayı yeniden başlat; çalışan sunucu model dosyalarını otomatik yenilemez.

Veriyi de ilk hâline getirmek istersen `python -m riviera.dataset` kullan. Bu komut `data/demo_reviews.csv` dosyasını yeniden yazar; kendi etiketli verini bu dosyanın üzerine koyma.

## 7. GitHub'a yükle

Önerilen depo adı: **riviera-ai**. Açıklama önerisi:

> Multilingual hotel review intelligence for Antalya: NLP, XGBoost, multi-task deep learning and a FastAPI dashboard.

Terminalde, henüz Git deposu başlatılmamışsa:

```bash
git init
git add .
git commit -m "Add Riviera AI hotel review intelligence project"
git branch -M main
```

GitHub'da boş bir depo oluştur. Aşağıdaki kullanıcı adı yer tutucusunu kendi adınla değiştir:

```bash
git remote add origin https://github.com/KULLANICI_ADIN/riviera-ai.git
git push -u origin main
```

`.gitignore`, sanal ortamı ve çalışma veritabanını dışarıda tutar. `models/` bu küçük demoda özellikle takip edilir; ilk çalıştırmada eğitim zorunluluğunu kaldırır. `.env`, gerçek otel verisi veya kişisel bilgi yükleme. Bu paket GitHub hesabına otomatik gönderilmemiştir.

## Sık karşılaşılan durumlar

- **Adres açılmıyor:** terminalde sunucunun çalıştığını ve doğru portu kontrol et.
- **Port kullanılıyor:** `python run.py --demo --port 8001`; sonra `http://127.0.0.1:8001` aç.
- **Modül bulunamadı:** aynı sanal ortamın Python'u ile kurulum ve çalıştırma komutlarını uygula.
- **Model sürümü uyarısı:** `requirements-lock.txt` ile aynı paketleri kur veya modelleri kendi ortamında yeniden eğit.
- **CSV reddedildi:** `data/import_template.csv` dosyasını örnek al. UTF-8 ve TR/EN/DE/RU dil kodları gerekir.
- **Bütün tahminler doğru değil:** beklenen bir prototip sınırlaması. Hataları `reports/challenge_predictions.csv` üzerinden incele; gerçek başarı için bağımsız otel verisi gerekir.
