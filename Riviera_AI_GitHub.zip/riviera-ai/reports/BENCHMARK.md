# Included benchmark results

> These are actual results from the included run, on synthetic AI-authored text. They are not real-hotel accuracy estimates.

## Template test

| Model | Validation mean macro-F1 | Test sentiment macro-F1 | Test topic macro-F1 | Training seconds |
| --- | ---: | ---: | ---: | ---: |
| logreg | 1.000 | 1.000 | 1.000 | 0.421 |
| xgboost | 0.818 | 0.780 | 0.837 | 5.322 |
| neural_mlp | 0.802 | 0.813 | 0.776 | 0.393 |

Default selected from validation: **logreg**.

## Separately written 48-example synthetic challenge

| Model | Sentiment macro-F1 | Topic macro-F1 | Human-review flag rate |
| --- | ---: | ---: | ---: |
| logreg | 0.734 | 0.968 | 37.5% |
| xgboost | 0.487 | 0.816 | 43.8% |
| neural_mlp | 0.616 | 0.904 | 22.9% |

Metrics include all top-class candidate predictions, including those flagged for human review. The review gate does not modify the labels used in this report.

The template corpus shares vocabulary and grammar between partitions. The challenge set uses different sentences but remains small, fixed and AI-authored. The drop in sentiment performance is evidence of limited generalization within these examples, not a quantified estimate of performance on actual guests.

## Reproduction details

- Dataset split sizes: {'train': 3072, 'validation': 768, 'test': 768}.
- Neural epochs run: 27; best validation-loss epoch: 13.
- Libraries: {'numpy': '2.3.5', 'scikit-learn': '1.8.0', 'xgboost': '3.4.1', 'scipy': '1.17.0'}.
- Python: 3.12.14. Numerical timings and exact floating-point outputs depend on the host.
- Full metrics: metrics.json; challenge predictions: challenge_predictions.csv.
- Preprocessing fits on train only. Default selection uses validation only. No exhaustive hyperparameter optimization is claimed.
- The baseline uses sparse TF-IDF while the other models use dense SVD features; representation differences also affect the comparison.
