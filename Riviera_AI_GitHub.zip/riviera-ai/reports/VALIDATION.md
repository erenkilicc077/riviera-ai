# Validation of this delivery

The following checks were actually run on the included code and artifacts in a Linux / Python 3.12 environment.

| Check | Result |
| --- | --- |
| Generate and validate 4,608 synthetic rows | Passed; reproducible seed and disjoint core/text groups |
| Fit logistic regression, XGBoost and NumPy multi-task MLP | Completed; actual artifacts and metrics included |
| Evaluate separate 48-example synthetic challenge | Completed; every candidate prediction saved |
| `python -m pytest -q` | **17 passed** |
| Numerical backpropagation gradient comparison | Passed as part of the test suite |
| `python -m ruff check --select F riviera scripts tests run.py` | Passed |
| Python compilation / JavaScript syntax | Passed |
| All 8 notebook Python cells | Executed successfully with training toggle off |
| Editable package installation with dev dependencies | Completed |
| Desktop Chromium, 1440 × 1100 | Dashboard, real API data, prediction, three-model comparison, save, resolution, filters, CSV import and export passed |
| Mobile Chromium, 390 × 844 | Dashboard and German prediction flow passed |
| Browser JavaScript errors | None observed during these flows |
| Horizontal page overflow | None on tested desktop, mobile overview and mobile lab viewports |

The Python suite covers leakage detection, gradient correctness, a learnable toy task, NPZ roundtrip, actual predictions from every model, persistence/deduplication, filters, status updates, missing models, unknown text, atomic imports, invalid input and spreadsheet formula neutralization.

The dependency combination emits one Starlette deprecation warning about its current httpx test transport. Tests pass; the warning is recorded rather than hidden. Updating the transport can be handled when upgrading dependencies.

Browser checks used actual locally served pages and the model API, not static screenshots or mocked responses. Images used for internal visual inspection are not part of this release. The included banner is an original SVG asset.

## Not verified here

- Docker build/run: configuration supplied, Docker engine not exercised.
- Windows/macOS installation: commands supplied; the executed environment was Linux.
- Google Colab hosting/runtime: setup guide supplied; notebook code cells were executed locally.
- Hosted GitHub Actions: workflow supplied; a GitHub repository was not created or pushed by this delivery.
- Any real hotel dataset, production-scale load, authentication/tenant isolation, calibration, real operational outcome or commercial deployment.

Synthetic test and challenge scores should be interpreted under the limitations in `docs/DATA_CARD.md` and `docs/MODEL_CARD.md`.
