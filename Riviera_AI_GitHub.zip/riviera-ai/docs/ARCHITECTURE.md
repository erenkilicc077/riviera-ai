# Architecture and trade-offs

## Responsibilities

| Layer | Owns | Does not own |
| --- | --- | --- |
| Browser | Input, visualization, errors and human workflow | Model fitting / score invention |
| FastAPI + schemas | HTTP contracts, limits, validation | Learning algorithms |
| Application service | Validate → predict → transaction orchestration | Rendering |
| Review engine | Artifact loading, feature transforms, predictions, explicit review/routing rules | Database operations |
| SQLite repository | Parameterized queries, deduplication, transactions, aggregates | Model inference |
| Offline training | Reproducible fitting, selection, reports | Request-time training |

## Request lifecycle

An analysis request is validated by Pydantic. The preloaded engine transforms the text using train-fitted preprocessing and returns candidate labels, uncalibrated scores and routing suggestions. Analysis alone does not persist a record. Saving runs prediction again under the selected model and commits a record to SQLite. The dashboard aggregates stored predictions; it does not regenerate arbitrary statistics.

CSV import validates the complete batch before prediction or mutation. A single transaction writes valid records. A unique SHA-256 fingerprint over normalized text, declared language, district and date skips repeats. Distinct dates intentionally represent distinct review events. The fingerprint is not a guest identity or cross-platform deduplication system.

## Why a modular monolith?

A single Python app is inspectable and easy to run for a student or reviewer. The domain, model and persistence modules have separate responsibilities. A separate queue, container per model or microservice layer would add deployment work without a measured need in this local demo.

SQLite is sufficient for one local workspace. WAL mode and per-operation connections support simple concurrent reads/writes; SQLite still serializes writes. No cross-process distributed locking is claimed.

Models load once at application startup. Batched inference transforms text in one call. Learned transforms are never re-fit during requests. Re-training requires an application restart. Artifacts and metadata must be deployed together; hot swaps and a model registry are not implemented.

## Latency and throughput

The API reports measured per-item inference time for feature transformation and prediction; it excludes the initial artifact load and database operations. Batch time is divided by the batch size. These timings are machine-dependent diagnostics, not a production SLO. The project uses a single CPU thread for numerical inference to avoid hidden oversubscription.

The linear baseline consumes sparse features while XGBoost/MLP consume dense SVD features. This comparison includes both representation and algorithm differences. The neural network shares a backbone between sentiment and topic; equal task-loss weights are a fixed experimental choice.

## Limits that are implemented

- 3,000 characters per review; at least five characters.
- 100 texts per prediction batch; 500 rows per CSV import.
- 1 MiB request-body validation. The application buffers request bodies; a production reverse proxy should enforce a streaming limit as well.
- 10,000 rows per export, with an explicit error rather than silent truncation.
- Pagination, date/district filters, foreign-label validation, parameterized SQL and spreadsheet formula neutralization.
- Caller-declared language; no language detector. No external network call on the normal inference path.

## Before a real hotel pilot

Add authentication, role-based access, hotel/tenant identifiers and isolation, request/audit logs with content minimization, retention/deletion policies, backups, deployment monitoring and a model rollout/rollback procedure. Collect an authorized representative labeled dataset, measure per-language/per-topic quality and calibrate the review gate.

If real volume requires it, use PostgreSQL for multiple writers, a background queue for large imports, worker batching and an artifact registry with immutable versions. Introduce these based on measured bottlenecks and operating needs. The included Dockerfile is a packaging starting point, not a managed production deployment.
