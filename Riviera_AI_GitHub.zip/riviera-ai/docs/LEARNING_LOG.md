# Eren's learning log

Use this file for changes you actually make. No entries are pre-filled as completed personal work.

| Date | Question / hypothesis | File or experiment | Validation result | What I learned |
| --- | --- | --- | --- | --- |
| YYYY-MM-DD | Why does one negative review become neutral? | Inspect challenge_predictions.csv | Add your measured finding | Add your explanation |

Suggested first experiment: change only the SVD dimension, retrain to a **separate model/report folder**, compare validation results, and document the trade-off. Keep the final test set out of parameter decisions. If a new SVD dimension is used, update the architecture text and UI descriptions too.
