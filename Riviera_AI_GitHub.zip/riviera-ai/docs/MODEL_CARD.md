# Model card

## Intended use

Educational comparison of multilingual text classifiers and integration into a locally running hotel-feedback workflow. The bundled models were fitted on synthetic text. They are not validated to make autonomous operational or safety decisions.

## Candidates

`logreg`: concatenated word (1–2 gram) and character (`char_wb`, 3–5 gram) TF-IDF features, with relative weights 1.0 and 0.7; two `LogisticRegression(C=4, max_iter=600)` heads.

`xgboost`: train-fitted TF-IDF → 96-component `TruncatedSVD` → `StandardScaler` → clipping to [-8, 8]; two XGBoost heads, 130 trees, depth 4, learning rate 0.09, row sampling 0.9, feature sampling 0.85. Standardization is shared for the dense experiments; it is not required by tree models themselves.

`neural_mlp`: same dense representation; 96-input → 96-ReLU → 48-ReLU shared backbone, sentiment (3) and topic (8) softmax heads. NumPy implements the complete forward/backward pass. Sum of task cross-entropies + L2 1e-4, Adam learning rate 0.0015, batch 128, up to 130 epochs, early stopping patience 14 on validation loss. Best weights are restored. No pretrained embeddings, Transformer or large model are used.

Artifacts record exact library versions, seed, data SHA-256, partition sizes, training timings, selection rule and reports in `models/metadata.json`. CPU/BLAS/platform differences can cause small neural numerical differences.

## Evaluation

Default model: maximum mean validation macro-F1 over sentiment and topic. Test and challenge are report-only. The classification reports cover every class; test results are also broken down by declared language. The challenge evaluator saves every mistake in CSV. Metrics include all top-class candidate labels, even if the human-review gate rejects them.

See `reports/BENCHMARK.md` for actual scores. No threshold search, probability calibration, confidence interval, formal statistical significance test or commercial outcome study is claimed.

## Human review and interpretation

A heuristic flags review if either task's maximum score is below 0.50, if known-word coverage is below 0.25 or if the feature vector is empty. Thresholds are illustrative fixed constants; they are not tuned or validated for a hotel deployment. Some unfamiliar text will still receive confident errors.

Routing is a deterministic mapping of topic to department; priority is a deterministic mapping of accepted sentiment. The UI states this explicitly. Linear sentiment n-gram contributions are available only for logistic regression; explanations are not fabricated for the neural model or XGBoost.

## Failure cases and responsible extension

Expect failures on new wording, negation, mixed feelings, irony, multiple topics, underrepresented language styles and out-of-domain text. A review's declared language does not constrain inference and is not automatically verified. Do not compare raw scores across models as calibrated reliability.

For a real pilot, create an authorized independent dataset, audit label consistency, hold out hotel/time groups, assess per-class/per-language metrics and false negatives, calibrate scores and rejection thresholds on separate validation data, and route uncertain cases to trained staff. Re-evaluate after meaningful model/data changes.
