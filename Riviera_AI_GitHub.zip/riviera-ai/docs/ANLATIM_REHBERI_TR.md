# Riviera AI'ı anlayarak anlatma rehberi

Bu rehber, projeyi bir staj görüşmesinde veya GitHub sunumunda kendi cümlelerinle açıklayabilmen için yazıldı. Önce uygulamayı çalıştır, ardından aşağıdaki dosyaları açarak anlatımı kodla eşleştir.

## 45 saniyelik giriş

“Antalya'daki otellerin farklı dillerdeki müşteri yorumlarını takip etme probleminden hareketle Riviera AI adlı bir NLP prototipi geliştirdim. Yorumun duygu durumunu ve baskın konusunu tahmin ediyor; açık kurallarla ilgili departmanı öneriyor. Aynı veri üzerinde lojistik regresyon, XGBoost ve iki gizli katmanlı bir sinir ağını karşılaştırdım. Modelleri FastAPI üzerinden sundum ve SQLite kullanan bir yönetim paneline bağladım. Başlangıç verisi sentetik olduğu için sonuçları gerçek otellerdeki başarı gibi sunmuyorum; gerçek veriyle doğrulama sonraki aşama.”

Bu metni ancak projeyi çalıştırıp değişiklik yaptıktan ve teknik tercihleri anlayabildikten sonra kendi çalışman olarak kullan. AI yardımını sorarlarsa açıkça belirt: “İlk iskeleti ve dokümantasyonu AI desteğiyle hazırladım; şu kısımları kendim değiştirip doğruladım: …” Boşluğu gerçekten yaptığın katkılarla doldur.

## 1. Hangi problemi çözüyoruz?

Bir otelin farklı dillerde yorumları olabilir. Yönetici için sorular şunlar:

- En çok hangi konu hakkında şikâyet var?
- Hangi yorum hangi ekibin değerlendirmesini gerektiriyor?
- Açık kalan şikâyetler var mı?
- Kullanılan modelin hataları ve sınırları neler?

Panel duygu ve konu tahminlerini özetler; çalışanlar takip durumunu elle değiştirir. Bir kaydı “Çözüldü” işaretlemek, sorunun gerçekten çözüldüğünü sistemin doğruladığı anlamına gelmez; operatörün beyanıdır.

Örnek: “Odadaki wifi çok kötüydü, sürekli kopuyordu.” → duygu adayı **negative**, konu adayı **wifi** → iş kuralıyla **Bilgi işlem** önerisi. Modelin skoru veya sözlük kapsamı düşükse insan incelemesi istenir.

## 2. Veri nereden geliyor?

`riviera/dataset.py` dört dil, sekiz konu ve üç duygu sınıfı için metinler üretir. İsim öbekleri, duygu ifadeleri ve konaklama bağlamları birleştirilir.

- Toplam: **4.608 sentetik yorum**.
- Eğitim: **3.072**; doğrulama: **768**; test: **768**.
- Ayrı mini sınama: **48 yorum**; şablon üreticisinden bağımsız yazılmıştır, yine AI üretimidir.
- Gerçek müşteri yorumu, gerçek otel puanı veya müşteri kimliği yoktur.

Önemli ayrıntı: aynı temel cümlenin iki farklı konaklama bağlamı vardır. Bunların biri eğitimde, diğeri testte olursa içerik sızıntısı olur. `group_id`, bu varyantları aynı bölümde tutar. `validate_dataset`, hem grup kesişimini hem normalize edilmiş aynı metnin bölümler arasında tekrarlanmasını reddeder.

**Bu önlem bütün benzerliği ortadan kaldırmaz.** Şablonların dil yapısı ve kelimeleri bölümler arasında ortaktır. Bu yüzden kolay sentetik testte yüksek skor görmek normaldir; gerçek otel verisindeki doğruluğu kanıtlamaz. Ayrı mini sınamada duygu skorunun düşmesi bu sınırlamayı görünür kılar.

## 3. Metin nasıl sayıya dönüşüyor?

Dosya: `riviera/train.py`; temizleme: `riviera/text.py`.

TF-IDF, bir kelimenin veya karakter parçasının bir yorum için ayırt ediciliğini sayısallaştırır. “Oda”, “wifi”, “clean”, “schlecht” gibi ifadeler modelin kullanabileceği özelliklere dönüşür.

Bu projede iki temsil birleştirilir:

- **Kelime 1–2 gramları:** “very good”, “hiç iyi” gibi tekli/ikili ifadeler.
- **Karakter 3–5 gramları:** sözcük çekimleri ve küçük yazım farkları arasında ortak parçalar.

Karakter n-gramları çok dilli bir dil modeli değildir; sadece yazıdaki tekrarları yakalayan sayısal özelliklerdir. Eğitimde yer almayan anlamları kendiliğinden anlayamazlar.

Türkçe karakterler ve Rusça metin korunur. “Değil”, “not”, “nicht” gibi olumsuzluklar silinmez. URL ve e-posta örüntülerini temizlemek, kapsamlı kişisel veri anonimleştirmesi değildir.

Vectorizer'ın `fit` işlemi sadece eğitim metinlerinde çalışır. Doğrulama/test metinlerinde sadece `transform` uygulanır. Böylece test sözlüğü veya IDF değerleri eğitime sızmaz.

## 4. Lojistik regresyon ne yapıyor?

Dosya: `riviera/train.py`, `LogisticRegression` bölümü.

İsminde regresyon geçse de burada sınıflandırma yapar. TF-IDF özelliklerinin ağırlıklı toplamını öğrenir. Bir model üç duygu sınıfından birini; diğeri sekiz konu sınıfından birini tahmin eder.

Avantajı: hızlıdır, metin sınıflandırmasında güçlü bir başlangıç sağlar ve katsayıları incelenebilir. Laboratuvardaki n-gram açıklaması, tahmin edilen duygu sınıfına pozitif katkı yapan **kelime özelliklerini** gösterir. Tüm açıklama veya nedensel kanıt değildir; karakter özellikleri bu kısa listede gösterilmez.

## 5. XGBoost ne yapıyor?

Yüksek boyutlu metin temsili önce **TruncatedSVD ile 96 bileşene** indirgenir. SVD ve ardından kullanılan StandardScaler eğitim verisine uydurulur.

XGBoost, ardışık ağaçlar oluşturarak önceki modelin hatalarını azaltmayı öğrenen gradient boosting yaklaşımıdır. Burada duygu ve konu için ayrı sınıflandırıcılar kullanılır. Ağaç sayısı ve derinliği sabit deney ayarlarıdır; kapsamlı hiperparametre araması yapılmaz.

SVD bilgi kaybettirebilir. Lojistik regresyonun ham TF-IDF kullanması, diğer iki adayın ise SVD özellikleri kullanması nedeniyle bu deney yalnızca algoritma farkını izole etmez; **temsil ve model tercihlerinin toplamını** karşılaştırır. “XGBoost metinde daima daha kötüdür” sonucu çıkarılamaz.

## 6. Deep learning tam olarak nerede?

Dosya: **`riviera/neural.py`**.

Ağ:

**96 giriş → 96 ReLU → 48 ReLU → iki çıkış başlığı**.

Bir başlık üç duygu sınıfı; diğeri sekiz konu sınıfı üretir. İki gizli katmanlı, gerçek eğitilebilir bir yoğun sinir ağıdır. Transformer, CNN, RNN veya LLM değildir. Önceden eğitilmiş dil modeli ağırlığı kullanılmaz. Küçük ve CPU üzerinde açıklanabilir bir deney olarak tasarlanmıştır.

**İleri yayılım:** `forward()`.

1. Girdi ağırlık matrisiyle çarpılıp bias eklenir.
2. ReLU, negatif değerleri sıfırlar.
3. İkinci gizli katmanda aynı işlem uygulanır.
4. İki başlık skor üretir; softmax her başlığın skorlarını toplamı bir olan çıktılara dönüştürür.

**Kayıp:** `loss_and_grad()`.

İki görevin çapraz entropi kaybı toplanır, ağırlıklara L2 cezası eklenir. Doğru sınıfa düşük çıktı verilirse kayıp büyür. İki görev ortak gövdeye birlikte gradyan gönderir; buna çok görevli öğrenme denir. Her görevden eşit sayıda sınıf olması gerekmez; kayıpların ağırlıkları burada eşittir.

**Geri yayılım:** zincir kuralıyla kaybın ağırlıklara göre türevleri hesaplanır. İki çıkışın katkıları ortak gövdede toplanır. ReLU'nun aktif olmadığı bölgelerde gradyan sıfırlanır.

**Adam:** `fit()` her ağırlık için gradyanın hareketli ortalamasını ve karesinin hareketli ortalamasını tutar. Bias düzeltmesi sonrası ağırlıklar güncellenir.

**Erken durdurma:** doğrulama kaybı belirli sayıda epoch boyunca iyileşmezse eğitim durur. En iyi doğrulama kaybındaki ağırlıklar geri yüklenir. Test kümesi bu kararda kullanılmaz.

**Matematik nasıl doğrulandı?** `tests/test_neural.py`, analitik gradyanı küçük sayısal farklarla hesaplanan gradyanla karşılaştırır. Ayrıca ağın basit bir problemi öğrenmesi ve NPZ kayıt/yükleme sonrası aynı çıktıyı vermesi sınanır.

## 7. Modeli nasıl seçiyoruz?

İki görevde **macro-F1** kullanılır. F1, precision ve recall'un harmonik ortalamasıdır. Macro-F1, her sınıfın F1 değerine eşit ağırlık verir.

Seçim skoru: duygu doğrulama macro-F1 ile konu doğrulama macro-F1'in ortalaması. Adaylar aynı bölümlerle değerlendirilir. En yüksek doğrulama ortalaması varsayılan model olur. Test ve challenge skorları daha sonra raporlanır.

Model skorlarının kendisi kalibre edilmemiştir. Bir modelin 0,90 üretmesi, gerçek dünyada %90 doğruluk garantisi taşımaz. İki farklı modelin softmax skorlarını da doğrudan güvenilirlik sıralaması gibi kullanma.

## 8. Departmanı AI mı buluyor?

**Konu ve duygu öğrenilir; departman ve öncelik açık kurallarla önerilir.** `config.py` eşlemeleri içerir.

| Model çıktısı | Kuralın önerisi |
| --- | --- |
| `cleanliness` | Kat hizmetleri |
| `food` | Yiyecek ve içecek |
| `room` | Teknik servis |
| `wifi` | Bilgi işlem |
| `staff`, `location` | Misafir ilişkileri |
| `noise` | Ön büro |
| `facilities` | Tesis yönetimi |

Duygu veya konu en yüksek skoru 0,50'nin altındaysa ya da bilinen kelime kapsamı 0,25'in altındaysa insan incelemesi işaretlenir. Bu sabit değerler öğretici bir **heuristic**tir; gerçek veri üzerinde optimize edilmiş veya kalibre edilmiş eşikler değildir. İnceleme işareti olmayan olumsuz yorum “high” önceliği alır. Bu öncelik acil durum tespiti değildir.

## 9. Yazılım mühendisliği tarafı

- `api.py`: HTTP, girdi şeması ve hata kodları.
- `service.py`: tahmin ve kayıt adımlarının koordinasyonu.
- `inference.py`: modellerin bir kez yüklenmesi ve toplu tahmin.
- `store.py`: SQL ve veritabanı işlemleri.
- `web/`: kullanıcı arayüzü.

CSV'nin bütün satırları önce doğrulanır. Hatalı bir satır varsa hiçbir kayıt eklenmez. Geçerli veri tek veritabanı transaction'ında kaydedilir. Parmak izi normalize metin, bölge, dil ve tarih üzerinden tekrarları engeller.

SQL parametreleri doğrudan metne birleştirilmez. Kullanıcı yorumları DOM'a `textContent` ile eklenir. CSV dışa aktarmada formül olarak yorumlanabilecek başlangıç karakterleri güvenli biçime çevrilir. Veritabanı varsayılan olarak `runtime/` altında kalır ve GitHub'a gitmez.

## 10. Üç dakikalık ekran gösterimi

1. **0:00–0:30:** otel geri bildirim problemi ve sentetik veri sınırını açıkla.
2. **0:30–1:10:** laboratuvarda bir yorumu üç modelle karşılaştır.
3. **1:10–1:40:** yorumu kaydet, takip durumunu değiştir, açık şikâyet sayısını göster.
4. **1:40–2:20:** model ekranında iki değerlendirme setini göster; neden doğrusal modelin seçildiğini açıkla.
5. **2:20–3:00:** `neural.py` içindeki `forward`, `loss_and_grad`, `fit` fonksiyonlarını ve gradyan testini aç. Gerçek veriyle pilot planıyla bitir.

## 11. Sorulabilecek sorular

**Neden deep learning modeli varsayılan değil?** Adayları doğrulama sonucuyla seçiyoruz. Basit şablonlu veri ve yüksek boyutlu TF-IDF, doğrusal modele avantaj sağlıyor. SVD, ağ mimarisi ve eğitim ayarları da sonucu etkiliyor.

**Bu proje üretimde çalışır mı?** Yerelde çalışan bir prototip. Gerçek veri doğrulaması, kullanıcı kimlik doğrulaması, otel bazlı veri ayrımı, erişim kaydı, yedekleme ve operasyonel izleme eklenmeden üretim sistemi olduğunu söylemem.

**Veri sızıntısını nasıl engelledin?** Bağlam varyantlarını grupladım; normalize metin ve grup kesişimi testleri ekledim. Öğrenilen ön işleme adımları sadece eğitim bölümüne uyduruluyor. Şablon benzerliğinin yine kaldığını raporda belirtiyorum.

**Bir yorumda hem yemek hem temizlik varsa?** Mevcut model tek baskın konuyu tahmin eder. Daha iyi bir sürümde çok etiketli sınıflandırma veya cümle bazlı aspect sentiment analizi gerekir.

**Skor niye güven değeri değil?** Kalibrasyon değerlendirmesi yapılmadı. Gerçek etiketli doğrulama verisiyle kalibrasyon, reliability diagram ve Brier score gibi araçlar incelenebilir.

**100 otel gelirse?** Önce otel/tenant kimliği, yetkilendirme ve PostgreSQL eklerim; ölçülen darboğaza göre toplu iş kuyruğu ve worker kullanırım. Model servisinde batch inference ve sürümleme düşünürüm. Baştan onlarca servis kurmam.

**LLM nerede?** Bu sürüm LLM kullanmaz. Mevcut hedef, klasik ML ve yoğun sinir ağı eğitimini gözle görünür biçimde uygulamak. Daha sonra önceden eğitilmiş çok dilli modelle kontrollü karşılaştırma yapılabilir.

## 12. Projeyi sahiplenmek için gerçek katkı listesi

1. Mini sınamadaki **en az beş yanlış tahmini** aç, nedenlerini not et.
2. Yeni bir yorum ekle; modeli eğitmeden tahmin et. Beklentinle karşılaştır.
3. `C`, SVD bileşen sayısı veya gizli katman boyutundan **birini** değiştir. Önceki ve sonraki doğrulama sonucunu not et. Teste sürekli bakarak ayar seçme.
4. Kendi deneylerin çoğalınca mevcut challenge setinin de kararlarına sızabileceğini kabul et; yeni, hiç görülmemiş bir son test seti ayır.
5. Bir arayüz iyileştirmesini kendin yap; örneğin yeni bir filtre veya açıklayıcı hata mesajı.
6. `docs/LEARNING_LOG.md` dosyasına gerçek katkılarını yaz ve ayrı commit'ler oluştur.

Bir mühendisle konuşurken en güçlü anlatım; seçtiğin yöntemin gerekçesini, ölçtüğün sonucu, fark ettiğin hatayı ve sonraki deneyi birlikte açıklayabilmendir.
