# Notebook'u Google Colab'da açmak

Bu yol **deney notebook'u** içindir. Yönetim paneli için yerel bilgisayar kurulumu daha uygundur; Colab'daki localhost adresi telefonunun veya bilgisayarının localhost adresi değildir.

1. `notebooks/01_riviera_walkthrough.ipynb` dosyasını Colab'a yükle.
2. İlk yeni kod hücresinde aşağıdakini çalıştır, indirilen proje ZIP'ini seç:

```python
from google.colab import files
uploaded = files.upload()
```

3. Sonraki hücrede, yüklediğin ZIP'i denetleyerek çıkar:

```python
from pathlib import Path
import zipfile

archive_name = next(name for name in uploaded if name.lower().endswith('.zip'))
destination = Path('/content').resolve()
with zipfile.ZipFile(archive_name) as archive:
    for item in archive.infolist():
        resolved = (destination / item.filename).resolve()
        if not resolved.is_relative_to(destination):
            raise ValueError('Güvensiz ZIP yolu')
    archive.extractall(destination)
```

4. Bağımlılıkları kur:

```python
%pip install -e /content/riviera-ai
```

5. Notebook hücrelerini sırayla çalıştır. Paketle gelen scikit-learn sürümü farklıysa önce şu hücrelerle modelleri yeniden üret:

```python
import subprocess
import sys
subprocess.run([sys.executable, '-m', 'riviera.train'], cwd='/content/riviera-ai', check=True)
subprocess.run([sys.executable, '-m', 'riviera.evaluate'], cwd='/content/riviera-ai', check=True)
```

Python 3.11+ gerekir. GPU gerekmez. Google Colab üzerinde bizzat çalıştırma bu paket için doğrulanmamıştır; notebook'un Python hücreleri yerel ortamda kontrol edilmiştir. Colab'ın mevcut paketleriyle çakışma olursa çalışma zamanını yeniden başlatıp kurulumu ve eğitimi tekrarla.
