# Data card

**All bundled text is synthetic and AI-authored. No scraping or actual guest records.**

| File | Origin | Rows | Role |
| --- | --- | ---: | --- |
| `data/demo_reviews.csv` | Deterministic combinations in `riviera/dataset.py`, seed 42 | 4,608 | Train / validation / test |
| `data/challenge_reviews.csv` | Separately authored, fixed synthetic sentences | 48 | Additional report-only evaluation |
| `data/import_template.csv` | Four fixed synthetic examples | 4 | UI import template |
| Seeded SQLite records | Sample of the synthetic test corpus | 96 | Operational dashboard demonstration |

The 96 operational examples are sampled by known label to create a useful mix (48 negative, 24 neutral, 24 positive). Their **displayed** classifications and all aggregate metrics use actual model predictions, not those sampling labels. Re-running `--demo` on the same day skips duplicates; on another day the relative dates change and new events may be inserted. Runtime records are excluded from the ZIP and Git.

## Labels

- Sentiment: `negative`, `neutral`, `positive`.
- Single dominant topic: `cleanliness`, `facilities`, `food`, `location`, `noise`, `room`, `staff`, `wifi`.
- Language: `tr`, `en`, `de`, `ru`, assigned by construction/caller.
- Split: `train` 3,072 / `validation` 768 / `test` 768.

Each language/topic/sentiment cell has 24 core sentences. Sixteen core groups go to train, four to validation and four to test. Every core has two context wrappers. The entire core group remains in one partition. Validation rejects overlapping group IDs and identical normalized texts across partitions.

## Known weaknesses

The generator has repetitive grammar, limited vocabulary, balanced artificial classes and some unnatural expressions. Phrases, sentiment words and general syntax are shared across partitions even when core sentences do not overlap. Template-test scores are therefore optimistic and **must not be advertised as real-world accuracy**.

The challenge set is small, AI-authored, fixed and intentionally simpler than unrestricted real guest reviews. It is not a statistically representative test and has no independent human annotation audit. Repeatedly examining it can make it part of the development process; a later serious evaluation needs a fresh holdout set.

There is no labeled sarcasm, broad code-switching, multi-aspect annotation, star-rating target, genuine timestamp distribution or real hotel population. Districts and operational dates are invented to demonstrate filtering, not to describe the Antalya tourism market.

## Licensing and replacement

Bundled synthetic texts use CC0; code uses MIT. Real hotel/platform exports require separate authorization and licensing. See `docs/REAL_DATA.md`. No personal guest identifiers are needed by the demo schema. Text can still contain personal information; the cleaner is not a complete anonymizer.
