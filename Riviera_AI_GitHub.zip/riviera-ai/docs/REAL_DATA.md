# Moving from synthetic examples to an authorized hotel pilot

1. Obtain an authorized export from the hotel's own feedback workflow, or another explicitly licensed dataset. A review-platform URL alone is not permission to scrape or republish data.
2. Minimize personal information. Names, booking references and contact details are unnecessary for these labels. Apply proper review/anonymization before putting any real text in a public repository.
3. Have at least two competent annotators examine a subset. Define negative/neutral/positive, a single dominant topic, and an ambiguity policy. The current model cannot represent several topics at once.
4. Choose the generalization question **before splitting**. Use hotel-level groups to evaluate unseen hotels, guest/thread groups to prevent repeated-conversation leakage, or chronological holdout for future feedback. One grouping scheme does not automatically solve all three problems.
5. Freeze a final test set. Tune representations, thresholds and calibration only on train/validation. Check every language and topic, and inspect errors with the hotel team.

## Expected labeled schema

`text,language,sentiment,topic,group_id`

Use the labels in `riviera/config.py`. `group_id` must identify the unit you want kept together. At least six independent groups are required by the helper, and every split must cover all supported languages and task classes. Small datasets will often fail that requirement; gather more labeled data rather than silently dropping missing classes.

```bash
python scripts/prepare_real_data.py --input PRIVATE_LABELED_EXPORT.csv --output data/real_reviews.csv
python -m riviera.train --data data/real_reviews.csv --output models --reports reports
```

The helper uses deterministic group-aware 70/15/15 splitting and then the same leakage/schema checks as the demo. It is a random group split, **not chronological splitting**. For a time-based study, build and review chronological splits separately. Duplicate normalized texts in different groups/splits are rejected rather than silently relabeled.

Do not overwrite the synthetic generator or claim that its scores transfer. Training on real data changes metadata to `user_supplied`. The separate bundled synthetic challenge can still be run as a smoke test, but real pilot results should come from an independently annotated real holdout and be reported separately.

`data/real_reviews.csv`, private exports and newly trained artifacts should stay private unless their publication is authorized. The provided `.gitignore` excludes the conventional private paths; review all staged files before publishing.
