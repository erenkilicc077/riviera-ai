# Primary learning references

Project implementation and synthesis are original to this educational package; these references explain underlying methods and engineering principles.

- [scikit-learn text feature extraction](https://scikit-learn.org/stable/modules/feature_extraction.html#text-feature-extraction)
- [scikit-learn LogisticRegression](https://scikit-learn.org/stable/modules/generated/sklearn.linear_model.LogisticRegression.html)
- [scikit-learn TruncatedSVD](https://scikit-learn.org/stable/modules/generated/sklearn.decomposition.TruncatedSVD.html)
- [scikit-learn cross-validation and group splits](https://scikit-learn.org/stable/modules/cross_validation.html)
- [XGBoost Python API](https://xgboost.readthedocs.io/en/stable/python/python_api.html)
- [Adam: A Method for Stochastic Optimization — Kingma & Ba](https://arxiv.org/abs/1412.6980)
- [FastAPI tutorial](https://fastapi.tiangolo.com/tutorial/)
- [Pydantic validation](https://docs.pydantic.dev/latest/concepts/validators/)
- [SQLite transactions](https://www.sqlite.org/lang_transaction.html)
- [Google Rules of Machine Learning](https://developers.google.com/machine-learning/guides/rules-of-ml)
- [A Philosophy of Software Design — author page](https://web.stanford.edu/~ouster/cgi-bin/aposd.php)
- [ByteByteGo: System Design Interview volume comparison](https://blog.bytebytego.com/p/system-design-interview-books-volume)

The mentor's broader software-engineering reading list motivates the project's separate modules, explicit boundaries, reproducible evaluation and discussion of scaling trade-offs. The project does not reproduce the books' text or claim to cover their entire content.
