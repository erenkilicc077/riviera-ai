"""Prepare an authorized labeled CSV without changing the synthetic dataset."""

import argparse
from pathlib import Path
import sys

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))

import pandas as pd
from sklearn.model_selection import GroupShuffleSplit

from riviera.dataset import validate_dataset


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--input", type=Path, required=True)
    parser.add_argument("--output", type=Path, default=Path("data/real_reviews.csv"))
    args = parser.parse_args()
    df = pd.read_csv(args.input)
    required = {"text", "language", "sentiment", "topic", "group_id"}
    if not required.issubset(df) or df[list(required)].isna().any().any():
        raise SystemExit("Required non-null columns: text, language, sentiment, topic, group_id")
    if df.group_id.nunique() < 6:
        raise SystemExit("Need at least six independent groups; more are usually required for label coverage.")
    train_index, heldout_index = next(GroupShuffleSplit(n_splits=1, test_size=0.30, random_state=42)
                                     .split(df, groups=df.group_id))
    heldout = df.iloc[heldout_index]
    validation_local, test_local = next(GroupShuffleSplit(n_splits=1, test_size=0.5, random_state=43)
                                       .split(heldout, groups=heldout.group_id))
    df = df.copy()
    df["split"] = "train"
    df.loc[df.index[heldout_index[validation_local]], "split"] = "validation"
    df.loc[df.index[heldout_index[test_local]], "split"] = "test"
    df["source"] = "user_supplied"
    validate_dataset(df)
    args.output.parent.mkdir(parents=True, exist_ok=True)
    df.to_csv(args.output, index=False)
    print(df["split"].value_counts().to_string())
    print(f"Saved {args.output}. Review permissions and holdout design before training or publication.")


if __name__ == "__main__":
    main()
