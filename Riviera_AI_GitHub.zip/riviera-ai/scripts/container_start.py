import os

import uvicorn

if os.getenv("RIVIERA_SEED_DEMO") == "1":
    from riviera.config import ROOT
    from riviera.inference import ReviewEngine
    from riviera.service import seed_demo
    from riviera.store import ReviewStore

    seed_demo(ReviewStore(os.getenv("RIVIERA_DB_PATH", ROOT / "runtime/reviews.sqlite")), ReviewEngine())

uvicorn.run("riviera.api:app", host="0.0.0.0", port=8000)
