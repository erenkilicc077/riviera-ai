"""One vocabulary shared by training, inference, API and the dashboard."""

from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
SENTIMENTS = ["negative", "neutral", "positive"]
TOPICS = ["cleanliness", "facilities", "food", "location", "noise", "room", "staff", "wifi"]
LANGUAGES = ["tr", "en", "de", "ru"]
DISTRICTS = ["Side", "Belek", "Lara", "Kemer", "Alanya", "Antalya Merkez"]
TOPIC_TR = {
    "cleanliness": "Temizlik", "facilities": "Havuz ve plaj", "food": "Yeme içme",
    "location": "Konum", "noise": "Gürültü", "room": "Oda ve konfor",
    "staff": "Personel", "wifi": "İnternet",
}
DEPARTMENTS = {
    "cleanliness": "Kat hizmetleri", "facilities": "Tesis yönetimi", "food": "Yiyecek ve içecek",
    "location": "Misafir ilişkileri", "noise": "Ön büro", "room": "Teknik servis",
    "staff": "Misafir ilişkileri", "wifi": "Bilgi işlem",
}
ACTIONS = {
    "cleanliness": "Kat hizmetleriyle oda kontrolü ve yeniden temizlik planlayın.",
    "facilities": "Havuz veya plaj sorununun yerini doğrulayıp tesis ekibine aktarın.",
    "food": "Servis saatini ve sorunu kaydedip yiyecek içecek ekibine iletin.",
    "location": "Misafire ulaşım ve çevre olanakları konusunda bilgi verin.",
    "noise": "Gürültünün saatini doğrulayın; sessiz oda veya müdahale seçeneklerini değerlendirin.",
    "room": "Oda numarasını doğrulayıp teknik servis kontrolü planlayın.",
    "staff": "Olayın ayrıntısını misafirle doğrulayıp ilgili yöneticiye aktarın.",
    "wifi": "Bağlantı bölgesini ve cihazı öğrenip bilgi işlem kontrolü başlatın.",
}
