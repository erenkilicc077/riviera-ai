"""Independent AI-authored challenge set. This is still NOT real-world validation."""

import argparse
import hashlib
import json
from pathlib import Path

import pandas as pd
from sklearn.metrics import f1_score

from riviera.config import ROOT, SENTIMENTS, TOPICS
from riviera.inference import MODELS, ReviewEngine
from riviera.text import normalize_text


def evaluate(model_dir=ROOT / "models", reports=ROOT / "reports", challenge=ROOT / "data/challenge_reviews.csv"):
    model_dir, reports, challenge = Path(model_dir), Path(reports), Path(challenge)
    reports.mkdir(parents=True, exist_ok=True)
    df = pd.read_csv(challenge)
    training_data = pd.read_csv(ROOT / "data/demo_reviews.csv")
    if set(df.text.map(normalize_text)) & set(training_data.text.map(normalize_text)):
        raise ValueError("Challenge text overlaps with generated dataset.")
    engine = ReviewEngine(model_dir)
    scores, predictions = {}, []
    for model in MODELS:
        results = engine.predict(df.text.tolist(), model=model)
        sentiment = f1_score(df.sentiment, [r["sentiment"] for r in results], labels=SENTIMENTS, average="macro", zero_division=0)
        topic = f1_score(df.topic, [r["topic"] for r in results], labels=TOPICS, average="macro", zero_division=0)
        scores[model] = {"sentiment_macro_f1": float(sentiment), "topic_macro_f1": float(topic),
                         "mean_macro_f1": float((sentiment + topic) / 2),
                         "needs_review_rate": sum(r["needs_review"] for r in results) / len(results)}
        for row, result in zip(df.to_dict("records"), results):
            predictions.append({**row, "model": model, "predicted_sentiment": result["sentiment"],
                                "predicted_topic": result["topic"], "needs_review": result["needs_review"]})
    result = {"n": len(df), "source": "ai_authored_independent_challenge_v1",
              "sha256": hashlib.sha256(challenge.read_bytes()).hexdigest(), "models": scores,
              "metric_scope": "All candidate labels including outputs flagged for human review.",
              "selection_role": "report_only; does not select the serving model",
              "warning": "Small synthetic set; not evidence of real hotel performance."}
    (reports / "challenge_metrics.json").write_text(json.dumps(result, ensure_ascii=False, indent=2), encoding="utf-8")
    pd.DataFrame(predictions).to_csv(reports / "challenge_predictions.csv", index=False)
    metadata_path = model_dir / "metadata.json"
    metadata = json.loads(metadata_path.read_text(encoding="utf-8"))
    metadata["challenge"] = result
    metadata_path.write_text(json.dumps(metadata, ensure_ascii=False, indent=2), encoding="utf-8")
    (reports / "metrics.json").write_text(json.dumps(metadata, ensure_ascii=False, indent=2), encoding="utf-8")
    print(json.dumps(scores, indent=2))
    return result


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--models", type=Path, default=ROOT / "models")
    parser.add_argument("--reports", type=Path, default=ROOT / "reports")
    parser.add_argument("--challenge", type=Path, default=ROOT / "data/challenge_reviews.csv")
    args = parser.parse_args()
    evaluate(args.models, args.reports, args.challenge)


if __name__ == "__main__":
    main()
