"""SQLite repository with parameterized SQL, idempotent inserts and transactions."""

import hashlib
import json
import sqlite3
import uuid
from contextlib import contextmanager
from datetime import date, datetime, timedelta, timezone
from pathlib import Path

from riviera.text import normalize_text


class ReviewStore:
    def __init__(self, path):
        self.path = Path(path)
        self.path.parent.mkdir(parents=True, exist_ok=True)
        with self.connection() as db:
            db.execute("PRAGMA journal_mode=WAL")
            db.executescript("""
                CREATE TABLE IF NOT EXISTS reviews (
                    id TEXT PRIMARY KEY, fingerprint TEXT NOT NULL UNIQUE,
                    text TEXT NOT NULL, language TEXT NOT NULL, district TEXT NOT NULL,
                    occurred_on TEXT NOT NULL, sentiment TEXT NOT NULL, topic TEXT NOT NULL,
                    needs_review INTEGER NOT NULL, priority TEXT NOT NULL,
                    status TEXT NOT NULL DEFAULT 'new', source TEXT NOT NULL,
                    prediction TEXT NOT NULL, created_at TEXT NOT NULL
                );
                CREATE INDEX IF NOT EXISTS idx_review_filter ON reviews(occurred_on, district);
            """)

    @contextmanager
    def connection(self):
        db = sqlite3.connect(self.path, timeout=20)
        db.row_factory = sqlite3.Row
        try:
            yield db
            db.commit()
        except Exception:
            db.rollback()
            raise
        finally:
            db.close()

    @staticmethod
    def decode(row):
        if row is None:
            return None
        result = dict(row)
        result["prediction"] = json.loads(result["prediction"])
        result["needs_review"] = bool(result["needs_review"])
        result.pop("fingerprint", None)
        return result

    def add_many(self, records):
        saved, duplicates = [], 0
        with self.connection() as db:
            for item in records:
                raw, prediction, source = item
                fingerprint = hashlib.sha256(json.dumps([
                    normalize_text(raw["text"]), raw["district"], raw["language"], str(raw["occurred_on"])
                ], ensure_ascii=False).encode()).hexdigest()
                review_id = uuid.uuid4().hex
                cursor = db.execute("""
                    INSERT OR IGNORE INTO reviews
                    (id, fingerprint, text, language, district, occurred_on, sentiment, topic,
                     needs_review, priority, source, prediction, created_at)
                    VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
                """, (review_id, fingerprint, raw["text"], raw["language"], raw["district"],
                      str(raw["occurred_on"]), prediction["sentiment"], prediction["topic"],
                      int(prediction["needs_review"]), prediction["priority"], source,
                      json.dumps(prediction, ensure_ascii=False), datetime.now(timezone.utc).isoformat()))
                if cursor.rowcount:
                    saved.append(review_id)
                else:
                    duplicates += 1
        return {"inserted": len(saved), "duplicates": duplicates, "ids": saved}

    def get(self, review_id):
        with self.connection() as db:
            return self.decode(db.execute("SELECT * FROM reviews WHERE id = ?", (review_id,)).fetchone())

    def update_status(self, review_id, status):
        with self.connection() as db:
            cursor = db.execute("UPDATE reviews SET status = ? WHERE id = ?", (status, review_id))
            return cursor.rowcount > 0

    @staticmethod
    def filters(district=None, sentiment=None, status=None, days=30):
        conditions, params = ["occurred_on >= ?"], [(date.today() - timedelta(days=days - 1)).isoformat()]
        for column, value in [("district", district), ("sentiment", sentiment), ("status", status)]:
            if value:
                conditions.append(f"{column} = ?")
                params.append(value)
        return " AND ".join(conditions), params

    def list(self, district=None, sentiment=None, status=None, days=30, limit=100, offset=0):
        where, params = self.filters(district, sentiment, status, days)
        with self.connection() as db:
            rows = db.execute(f"SELECT * FROM reviews WHERE {where} ORDER BY occurred_on DESC, created_at DESC LIMIT ? OFFSET ?",
                              [*params, limit, offset]).fetchall()
            total = db.execute(f"SELECT COUNT(*) FROM reviews WHERE {where}", params).fetchone()[0]
        return {"items": [self.decode(r) for r in rows], "total": total}

    def dashboard(self, district=None, days=30):
        where, params = self.filters(district=district, days=days)
        with self.connection() as db:
            summary = dict(db.execute(f"""
                SELECT COUNT(*) AS total, COALESCE(SUM(needs_review), 0) AS needs_review,
                    COALESCE(SUM(needs_review = 0), 0) AS classified,
                    COALESCE(SUM(sentiment = 'negative' AND needs_review = 0), 0) AS negative,
                    COALESCE(SUM(sentiment = 'positive' AND needs_review = 0), 0) AS positive,
                    COALESCE(SUM(sentiment = 'neutral' AND needs_review = 0), 0) AS neutral,
                    COALESCE(SUM(sentiment = 'negative' AND needs_review = 0 AND status != 'resolved'), 0) AS open_issues,
                    COALESCE(SUM(source = 'synthetic_demo'), 0) AS synthetic_count
                FROM reviews WHERE {where}
            """, params).fetchone())
            topics = [dict(r) for r in db.execute(f"""
                SELECT topic, COUNT(*) AS total,
                    SUM(sentiment = 'negative') AS negative,
                    SUM(sentiment = 'negative' AND status != 'resolved') AS open
                FROM reviews WHERE {where} AND needs_review = 0
                GROUP BY topic ORDER BY negative DESC, total DESC
            """, params).fetchall()]
            daily = [dict(r) for r in db.execute(f"""
                SELECT occurred_on AS day, COUNT(*) AS total,
                    SUM(sentiment = 'negative' AND needs_review = 0) AS negative
                FROM reviews WHERE {where} GROUP BY occurred_on ORDER BY occurred_on
            """, params).fetchall()]
            languages = [dict(r) for r in db.execute(f"SELECT language, COUNT(*) AS total FROM reviews WHERE {where} GROUP BY language", params).fetchall()]
        summary["negative_rate"] = round(summary["negative"] / summary["classified"], 4) if summary["classified"] else None
        return {"summary": summary, "topics": topics, "daily": daily, "languages": languages, "days": days}
