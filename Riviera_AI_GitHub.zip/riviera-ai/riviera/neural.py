"""A real two-hidden-layer, multi-task neural network implemented in NumPy.

Shared ReLU backbone -> sentiment softmax + topic softmax.
Backpropagation, Adam, L2 regularization and validation early stopping are explicit.
The point is to make the deep-learning mathematics inspectable on an ordinary CPU.
"""

import copy

import numpy as np


def softmax(logits):
    shifted = logits - logits.max(axis=1, keepdims=True)
    values = np.exp(shifted)
    return values / values.sum(axis=1, keepdims=True)


class MultiTaskMLP:
    def __init__(self, input_dim, hidden=(96, 48), n_sentiments=3, n_topics=8, seed=42, l2=1e-4):
        self.input_dim = input_dim
        self.hidden = tuple(hidden)
        self.n_sentiments = n_sentiments
        self.n_topics = n_topics
        self.seed = seed
        self.l2 = l2
        rng = np.random.default_rng(seed)
        h1, h2 = self.hidden
        self.params = {}
        for name, fan_in, fan_out in [("1", input_dim, h1), ("2", h1, h2),
                                     ("s", h2, n_sentiments), ("t", h2, n_topics)]:
            self.params[f"W{name}"] = (rng.normal(size=(fan_in, fan_out)) * np.sqrt(2 / fan_in)).astype("float32")
            self.params[f"b{name}"] = np.zeros(fan_out, dtype="float32")
        self.history = []

    def forward(self, x):
        p = self.params
        z1 = x @ p["W1"] + p["b1"]
        a1 = np.maximum(z1, 0)
        z2 = a1 @ p["W2"] + p["b2"]
        a2 = np.maximum(z2, 0)
        ps = softmax(a2 @ p["Ws"] + p["bs"])
        pt = softmax(a2 @ p["Wt"] + p["bt"])
        return ps, pt, (x, z1, a1, z2, a2)

    def loss_and_grad(self, x, ys, yt):
        ps, pt, (x, z1, a1, z2, a2) = self.forward(x)
        n = len(x)
        loss = -np.log(np.clip(ps[np.arange(n), ys], 1e-12, 1)).mean()
        loss -= np.log(np.clip(pt[np.arange(n), yt], 1e-12, 1)).mean()
        loss += 0.5 * self.l2 * sum((value * value).sum() for key, value in self.params.items() if key.startswith("W"))
        ds = ps.copy()
        dt = pt.copy()
        ds[np.arange(n), ys] -= 1
        dt[np.arange(n), yt] -= 1
        ds /= n
        dt /= n
        p = self.params
        grad = {"Ws": a2.T @ ds + self.l2 * p["Ws"], "bs": ds.sum(axis=0),
                "Wt": a2.T @ dt + self.l2 * p["Wt"], "bt": dt.sum(axis=0)}
        dz2 = (ds @ p["Ws"].T + dt @ p["Wt"].T) * (z2 > 0)
        grad.update(W2=a1.T @ dz2 + self.l2 * p["W2"], b2=dz2.sum(axis=0))
        dz1 = (dz2 @ p["W2"].T) * (z1 > 0)
        grad.update(W1=x.T @ dz1 + self.l2 * p["W1"], b1=dz1.sum(axis=0))
        return float(loss), grad

    def fit(self, x, ys, yt, validation, epochs=130, batch_size=128, lr=0.0015, patience=14):
        rng = np.random.default_rng(self.seed)
        first = {k: np.zeros_like(v) for k, v in self.params.items()}
        second = {k: np.zeros_like(v) for k, v in self.params.items()}
        best_loss, stale, step = float("inf"), 0, 0
        best_params = copy.deepcopy(self.params)
        xv, ysv, ytv = validation
        for epoch in range(epochs):
            order = rng.permutation(len(x))
            for start in range(0, len(x), batch_size):
                index = order[start:start + batch_size]
                _, grad = self.loss_and_grad(x[index], ys[index], yt[index])
                step += 1
                for key in self.params:
                    first[key] = 0.9 * first[key] + 0.1 * grad[key]
                    second[key] = 0.999 * second[key] + 0.001 * grad[key] ** 2
                    m = first[key] / (1 - 0.9 ** step)
                    v = second[key] / (1 - 0.999 ** step)
                    self.params[key] -= lr * m / (np.sqrt(v) + 1e-8)
            train_loss, _ = self.loss_and_grad(x, ys, yt)
            val_loss, _ = self.loss_and_grad(xv, ysv, ytv)
            self.history.append({"epoch": epoch + 1, "train_loss": train_loss, "validation_loss": val_loss})
            if val_loss < best_loss - 1e-5:
                best_loss, stale = val_loss, 0
                best_params = copy.deepcopy(self.params)
                self.best_epoch = epoch + 1
            else:
                stale += 1
            if stale >= patience:
                break
        self.params = best_params
        return self

    def predict_proba(self, x):
        sentiment, topic, _ = self.forward(x)
        return sentiment, topic

    def save(self, path):
        np.savez_compressed(path, **self.params, input_dim=self.input_dim, hidden=self.hidden,
                            n_sentiments=self.n_sentiments, n_topics=self.n_topics,
                            seed=self.seed, l2=self.l2)

    @classmethod
    def load(cls, path):
        with np.load(path, allow_pickle=False) as data:
            model = cls(int(data["input_dim"]), tuple(data["hidden"]),
                        int(data["n_sentiments"]), int(data["n_topics"]), int(data["seed"]), float(data["l2"]))
            model.params = {key: data[key].copy() for key in model.params}
        return model
