"use strict";

const $ = (id) => document.getElementById(id);
const titles = {overview:"Genel bakış",inbox:"Yorum kutusu",lab:"AI laboratuvarı",models:"Model karşılaştırması",guide:"Proje rehberi"};
const sentiments = {negative:"Olumsuz",neutral:"Nötr",positive:"Olumlu"};
const modelNames = {logreg:"Lojistik regresyon",xgboost:"XGBoost",neural_mlp:"Çok görevli sinir ağı"};
const samples = {
  tr:"Odadaki internet bağlantısı çok kötüydü, sürekli kopuyordu. Bu konuda yardım bekliyoruz.",
  en:"The breakfast buffet was excellent, with fresh food every morning. We really enjoyed it.",
  de:"Die Sauberkeit des Zimmers war leider sehr schlecht. Das Badezimmer wurde nicht gereinigt.",
  ru:"Работа персонала нам очень понравилась. Сотрудники были внимательными и помогали нам."
};
let inboxOffset = 0, inboxTotal = 0, refreshVersion = 0, inboxVersion = 0, lastAnalysis = null;
let toastTimer, busy = false;

function node(tag, attrs = {}, children = []) {
  const value = document.createElement(tag);
  Object.entries(attrs).forEach(([key, data]) => {
    if(key === "class") value.className = data;
    else if(key === "text") value.textContent = data;
    else value.setAttribute(key, data);
  });
  for (const child of children) value.append(child instanceof Node ? child : document.createTextNode(String(child)));
  return value;
}

function toast(message, error = false) {
  clearTimeout(toastTimer);
  $("toast").textContent = message;
  $("toast").className = `toast${error ? " error" : ""}`;
  $("toast").hidden = false;
  toastTimer = setTimeout(() => {$("toast").hidden = true;}, error ? 7500 : 4000);
}

async function api(path, options = {}) {
  const response = await fetch(path, options);
  let result;
  try {result = await response.json();} catch {throw new Error("Sunucudan geçerli yanıt alınamadı.");}
  if (!response.ok) {
    const detail = Array.isArray(result.detail) ? result.detail.map(x=>x.msg).join(" · ") : result.detail;
    throw new Error(detail || `İstek başarısız (${response.status}).`);
  }
  return result;
}
const postJSON = (path, body, method = "POST") => api(path, {method,headers:{"Content-Type":"application/json"},body:JSON.stringify(body)});
const percent = (v) => v === null || v === undefined ? "—" : `${(v*100).toLocaleString("tr-TR",{maximumFractionDigits:1})}%`;
const f1 = (v) => v.toFixed(3);
const shortDate = (date) => new Date(`${date}T12:00:00`).toLocaleDateString("tr-TR",{day:"numeric",month:"short"});

function navigate() {
  const raw = location.hash.slice(1), page = titles[raw] ? raw : "overview";
  document.querySelectorAll(".page").forEach(section => section.hidden = section.id !== `page-${page}`);
  document.querySelectorAll(".nav-link").forEach(link => {
    const active = link.dataset.page === page;
    link.classList.toggle("active",active);
    if(active) link.setAttribute("aria-current","page"); else link.removeAttribute("aria-current");
  });
  $("page-title").textContent = titles[page];
  if(page === "inbox") loadInbox().catch(error=>toast(error.message,true));
}

function queryFilters() {
  const query = new URLSearchParams({days:$("days-filter").value});
  if($("district-filter").value) query.set("district",$("district-filter").value);
  return query;
}

function renderReview(review, editable) {
  const prediction = review.prediction;
  const text = node("p",{class:"review-text",text:review.text});
  const metadata = node("div",{class:"review-meta"},[
    node("span",{text:review.district}),node("span",{text:"·"}),
    node("span",{text:shortDate(review.occurred_on)}),node("span",{text:"·"}),
    node("span",{text:prediction.topic_label}),node("span",{text:"·"}),
    node("span",{text:prediction.department}),
    node("span",{class:"source-tag",text:review.source === "synthetic_demo" ? "SENTETİK DEMO" : "KULLANICI GİRDİSİ"})
  ]);
  const body = node("div",{},[text,metadata]);
  if(editable) body.append(node("div",{class:"review-action",text:prediction.suggested_action}));
  const side = node("div",{class:"review-side"},[node("span",{
    class:`badge ${review.needs_review ? "review" : review.sentiment}`,
    text:review.needs_review ? "İnsan incelemesi" : sentiments[review.sentiment]
  })]);
  if(editable) {
    const select = node("select",{class:"review-status","aria-label":"Yorum takip durumu"});
    for(const [value,label] of [["new","Yeni"],["in_progress","İşlemde"],["resolved","Çözüldü"]]) {
      const option = node("option",{value,text:label});
      option.selected = review.status === value;
      select.append(option);
    }
    select.addEventListener("change",async()=>{
      select.disabled = true;
      try {await postJSON(`/api/reviews/${review.id}/status`,{status:select.value},"PATCH");toast("Takip durumu güncellendi.");await refreshAll();}
      catch(error) {select.value=review.status;toast(error.message,true);}
      finally {select.disabled=false;}
    });
    side.append(select);
  } else side.append(node("span",{class:"review-meta",text:review.status === "resolved" ? "Çözüldü" : review.status === "in_progress" ? "İşlemde" : "Yeni"}));
  return node("div",{class:"review-row"},[node("div",{class:"review-icon",text:review.language.toUpperCase()}),body,side]);
}

function renderReviews(id, items, editable) {
  const container = $(id);
  container.replaceChildren();
  if(!items.length) {container.append(node("p",{class:"empty",text:"Bu filtrelerle eşleşen yorum yok. AI laboratuvarından yorum ekleyebilirsiniz."}));return;}
  items.forEach(review=>container.append(renderReview(review,editable)));
}

async function loadInbox() {
  const requestVersion = ++inboxVersion;
  const query=queryFilters();
  query.set("limit","20");query.set("offset",String(inboxOffset));
  if($("sentiment-filter").value) query.set("sentiment",$("sentiment-filter").value);
  if($("status-filter").value) query.set("status",$("status-filter").value);
  const result = await api(`/api/reviews?${query}`);
  if(requestVersion!==inboxVersion) return;
  inboxTotal=result.total;
  renderReviews("inbox-reviews",result.items,true);
  $("review-total").textContent=`${result.total} yorum`;
  $("page-indicator").textContent=result.total ? `${inboxOffset+1}–${Math.min(inboxOffset+20,result.total)} / ${result.total}` : "0 yorum";
  $("previous-page").disabled=inboxOffset===0;
  $("next-page").disabled=inboxOffset+20>=result.total;
}

function svgNode(tag, attrs = {}, text) {
  const element = document.createElementNS("http://www.w3.org/2000/svg",tag);
  Object.entries(attrs).forEach(([key,value])=>element.setAttribute(key,value));
  if(text!==undefined) element.textContent=text;
  return element;
}

function drawTrend(daily) {
  const container=$("trend-chart");container.replaceChildren();
  $("chart-range").replaceChildren();
  if(!daily.length) {container.append(node("p",{text:"Henüz veri yok."}));return;}
  const first=new Date(`${daily[0].day}T12:00:00Z`), last=new Date(`${daily.at(-1).day}T12:00:00Z`);
  const map=new Map(daily.map(day=>[day.day,day]));
  const points=[];
  for(let date=new Date(first);date<=last;date.setUTCDate(date.getUTCDate()+1)) {
    const day=date.toISOString().slice(0,10);points.push(map.get(day)||{day,total:0,negative:0});
  }
  const width=560,height=204,left=28,right=12,top=12,bottom=22;
  const maximum=Math.max(1,...points.map(p=>p.total));
  const svg=svgNode("svg",{viewBox:`0 0 ${width} ${height}`,role:"img","aria-label":"Günlük toplam ve olumsuz yorum sayıları"});
  for(let i=0;i<4;i++) {
    const y=top+(height-top-bottom)*i/3;
    svg.append(svgNode("line",{x1:left,x2:width-right,y1:y,y2:y,stroke:"#edf0e7","stroke-dasharray":"3 5"}));
    svg.append(svgNode("text",{x:left-9,y:y+3,fill:"#a0ac96","font-size":8,"text-anchor":"end"},String(Math.round(maximum*(1-i/3)))));
  }
  const xy=(point,index,key)=>[left+index*(width-left-right)/Math.max(1,points.length-1),height-bottom-(height-top-bottom)*point[key]/maximum];
  for(const [key,color] of [["total","#5a876a"],["negative","#c99a76"]]) {
    svg.append(svgNode("polyline",{points:points.map((p,i)=>xy(p,i,key).join(",")).join(" "),fill:"none",stroke:color,"stroke-width":2,"stroke-linejoin":"round"}));
    points.forEach((point,index)=>{
      const [cx,cy]=xy(point,index,key),circle=svgNode("circle",{cx,cy,r:2,fill:color});
      circle.append(svgNode("title",{},`${point.day}: ${point[key]} ${key === "total" ? "toplam" : "olumsuz"}`));svg.append(circle);
    });
  }
  container.append(svg);
  $("chart-range").append(node("span",{text:shortDate(daily[0].day)}),node("span",{text:shortDate(daily.at(-1).day)}));
}

function drawTopics(topics, labels) {
  const container=$("topic-bars");container.replaceChildren();
  if(!topics.length){container.append(node("p",{class:"empty",text:"Henüz sınıflandırılmış yorum yok."}));return;}
  const max=Math.max(1,...topics.map(t=>t.negative));
  topics.forEach(topic=>{
    const fill=node("div",{class:"bar-fill"});fill.style.width=`${100*topic.negative/max}%`;
    container.append(node("div",{class:"topic-row"},[node("span",{text:labels[topic.topic]}),node("div",{class:"bar-track"},[fill]),node("span",{text:topic.negative})]));
  });
}

async function refreshAll() {
  const version=++refreshVersion,query=queryFilters();
  const [dashboard,latest]=await Promise.all([api(`/api/dashboard?${query}`),api(`/api/reviews?${query}&limit=4`)]);
  if(version!==refreshVersion) return;
  const s=dashboard.summary;
  $("kpi-total").textContent=s.total.toLocaleString("tr-TR");
  $("kpi-negative").textContent=percent(s.negative_rate);
  $("kpi-open").textContent=s.open_issues;
  $("kpi-review").textContent=s.needs_review;
  $("inbox-count").textContent=s.total;
  drawTrend(dashboard.daily);drawTopics(dashboard.topics,dashboard.topic_labels);
  renderReviews("latest-reviews",latest.items,false);
  await loadInbox();
}

function makeTable(headers, rows) {
  const head=node("tr");headers.forEach(text=>head.append(node("th",{text,scope:"col"})));
  const body=node("tbody");rows.forEach(values=>{const row=node("tr");values.forEach(text=>row.append(node("td",{text})));body.append(row);});
  return node("table",{},[node("thead",{},[head]),body]);
}

async function loadModels() {
  const metadata=await api("/api/models");
  const cards=$("model-cards");cards.replaceChildren();
  const descriptions={logreg:"Kelime ve karakter TF-IDF özellikleri üzerinde iki doğrusal sınıflandırıcı. İncelenebilir n-gram katkıları.",xgboost:"96 SVD özelliği üzerinde gradient boosting. Duygu ve konu için ayrı ağaç toplulukları.",neural_mlp:"96 → 96 → 48 ortak gövde ve iki softmax başlığı. NumPy ile geri yayılım, Adam ve erken durdurma."};
  Object.keys(modelNames).forEach((name,index)=>cards.append(node("article",{class:`card model-card ${name===metadata.selected_model?"selected":""}`},[
    node("span",{class:"small-label",text:name===metadata.selected_model?"DOĞRULAMADA SEÇİLEN":`MODEL 0${index+1}`}),
    node("h3",{text:modelNames[name]}),node("p",{text:descriptions[name]}),
    node("small",{text:`Eğitim: ${metadata.metrics[name].training_seconds.toFixed(1)} sn · sabit deney ayarları`})
  ])));
  $("benchmark-table").replaceChildren(makeTable(["Model","Duygu macro-F1","Konu macro-F1","Doğrulama ort."],Object.keys(modelNames).map(name=>[
    modelNames[name],f1(metadata.metrics[name].test.sentiment_macro_f1),f1(metadata.metrics[name].test.topic_macro_f1),f1(metadata.metrics[name].validation.mean_macro_f1)
  ])));
  if(metadata.challenge) $("challenge-table").replaceChildren(makeTable(["Model","Duygu macro-F1","Konu macro-F1","Örnek sayısı"],Object.keys(modelNames).map(name=>[
    modelNames[name],f1(metadata.challenge.models[name].sentiment_macro_f1),f1(metadata.challenge.models[name].topic_macro_f1),String(metadata.challenge.n)
  ])));
  else $("challenge-table").replaceChildren(node("p",{class:"footnote",text:"Mini sınama henüz çalıştırılmadı. python -m riviera.evaluate"}));
}

function invalidateAnalysis() {lastAnalysis=null;const save=$("save-analysis");if(save)save.disabled=true;}
function setBusy(value) {
  busy=value;$("analyze-button").disabled=value;$("compare-button").disabled=value;
  $("analyze-button").textContent=value?"Analiz ediliyor…":"✧ Analiz et";
  document.querySelectorAll("#analysis-form textarea, #analysis-form select, #analysis-form .sample").forEach(control=>control.disabled=value);
}
function formSnapshot() {return {text:$("review-text").value.trim(),language:$("review-language").value,district:$("review-district").value,model:$("model-select").value};}

function renderPrediction(value, snapshot) {
  const container=$("analysis-result");container.replaceChildren();
  container.append(node("div",{class:"result-main"},[node("h2",{text:sentiments[value.sentiment]}),node("span",{class:`badge ${value.needs_review?"review":value.sentiment}`,text:value.needs_review?"İnsan incelemesi gerekli":"Model önerisi"})]));
  container.append(node("div",{class:"result-topic"},[node("span",{text:"Baskın konu"}),node("strong",{text:`${value.topic_label} · ${percent(value.topic_score)}`})]));
  container.append(node("span",{class:"small-label",text:"DUYGU MODEL SKORLARI"}));
  Object.entries(value.sentiment_scores).forEach(([label,score])=>{
    const fill=node("div",{class:"bar-fill"});fill.style.width=`${100*score}%`;
    if(label==="negative")fill.style.background="#c38e6a";
    container.append(node("div",{class:"score-row"},[node("span",{text:sentiments[label]}),node("div",{class:"bar-track"},[fill]),node("strong",{text:percent(score)})]));
  });
  container.append(node("div",{class:"action-box"},[node("strong",{text:`Önerilen ekip: ${value.department}`}),node("p",{text:value.suggested_action})]));
  if(value.evidence.length) {
    container.append(node("p",{class:"footnote",text:"Doğrusal duygu modeline pozitif katkı yapan n-gramlar:"}));
    container.append(node("div",{class:"evidence"},value.evidence.map(e=>node("span",{text:e.ngram}))));
  }
  const save=node("button",{type:"button",class:"button primary",id:"save-analysis",text:"Yorum kutusuna kaydet"});
  save.addEventListener("click",async()=>{
    if(!lastAnalysis)return;
    save.disabled=true;
    try {await postJSON("/api/reviews",{...snapshot,model:value.model});toast("Yorum kaydedildi. Önerilen aksiyonu yorum kutusundan takip edebilirsiniz.");save.textContent="Kaydedildi ✓";lastAnalysis=null;await refreshAll();}
    catch(error){save.disabled=false;toast(error.message,true);}
  });
  container.append(save,node("p",{class:"score-note",text:value.score_note}),node("p",{class:"footnote",text:`${modelNames[value.model]} · ${value.latency_ms_per_item.toFixed(1)} ms / yorum. ${value.routing_note}`}));
  lastAnalysis={value,snapshot};
}

$("analysis-form").addEventListener("submit",async event=>{
  event.preventDefault();if(busy)return;
  const snapshot=formSnapshot();setBusy(true);invalidateAnalysis();
  try {const result=await postJSON("/api/predict",{text:snapshot.text,model:snapshot.model});renderPrediction(result,snapshot);}
  catch(error){toast(error.message,true);}finally{setBusy(false);}
});

$("compare-button").addEventListener("click",async()=>{
  if(busy||!$("analysis-form").reportValidity())return;
  const snapshot=formSnapshot();setBusy(true);
  try {
    const results=await Promise.all(Object.keys(modelNames).map(model=>postJSON("/api/predict",{text:snapshot.text,model})));
    const container=$("model-comparison-result");container.hidden=false;
    container.replaceChildren(node("h3",{class:"compare-title",text:"Aynı yorum, üç yaklaşım"}));
    results.forEach(result=>container.append(node("div",{class:"model-result-row"},[
      node("div",{},[node("strong",{text:modelNames[result.model]}),node("small",{text:`${result.latency_ms_per_item.toFixed(1)} ms / yorum`})]),
      node("div",{},[node("span",{class:`badge ${result.sentiment}`,text:`${sentiments[result.sentiment]} · ${percent(result.sentiment_score)}`}),node("small",{text:`${result.topic_label} · ${percent(result.topic_score)}${result.needs_review?" · İnsan incelemesi":""}`})])
    ])));
  }catch(error){toast(error.message,true);}finally{setBusy(false);}
});

for(const id of ["review-text","review-language","review-district","model-select"]) $(id).addEventListener("input",invalidateAnalysis);
document.querySelectorAll(".sample").forEach(button=>button.addEventListener("click",()=>{
  $("review-text").value=samples[button.dataset.language];$("review-language").value=button.dataset.language;invalidateAnalysis();$("review-text").focus();
}));
$("open-analyze").addEventListener("click",()=>{location.hash="lab";$("review-text").focus();});
window.addEventListener("hashchange",navigate);
for(const id of ["district-filter","days-filter"]) $(id).addEventListener("change",()=>{inboxOffset=0;refreshAll().catch(error=>toast(error.message,true));});
for(const id of ["sentiment-filter","status-filter"]) $(id).addEventListener("change",()=>{inboxOffset=0;loadInbox().catch(error=>toast(error.message,true));});
$("refresh").addEventListener("click",()=>refreshAll().catch(error=>toast(error.message,true)));
$("previous-page").addEventListener("click",()=>{inboxOffset=Math.max(0,inboxOffset-20);loadInbox().catch(error=>toast(error.message,true));});
$("next-page").addEventListener("click",()=>{if(inboxOffset+20<inboxTotal){inboxOffset+=20;loadInbox().catch(error=>toast(error.message,true));}});
$("export-button").addEventListener("click",()=>{location.href=`/api/export?${queryFilters()}`;});
$("import-button").addEventListener("click",()=>$("csv-file").click());
$("csv-file").addEventListener("change",async event=>{
  const file=event.target.files[0];if(!file)return;
  if(file.size>1024*1024){toast("CSV dosyası en fazla 1 MiB olabilir.",true);event.target.value="";return;}
  $("import-button").disabled=true;
  try{const result=await api("/api/reviews/import",{method:"POST",headers:{"Content-Type":"text/csv;charset=utf-8"},body:await file.text()});toast(`${result.inserted} yorum eklendi, ${result.duplicates} tekrar atlandı.`);inboxOffset=0;await refreshAll();}
  catch(error){toast(error.message,true);}finally{$("import-button").disabled=false;event.target.value="";}
});

async function initialize() {
  navigate();
  try {
    const health=await api("/api/health");
    $("system-state").replaceChildren(node("i"),document.createTextNode(health.models_ready?"Yerel modeller hazır":"Model eğitimi gerekli"));
    await Promise.all([refreshAll(),loadModels()]);
  }catch(error){$("system-state").textContent="Bağlantı / model hatası";toast(error.message,true);}
}
initialize();
