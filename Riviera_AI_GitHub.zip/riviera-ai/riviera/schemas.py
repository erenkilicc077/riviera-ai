"""API boundary validation; language is declared by the caller, not auto-detected."""

from datetime import date
from typing import Annotated, Literal

from pydantic import BaseModel, ConfigDict, Field, StringConstraints, field_validator

Text = Annotated[str, StringConstraints(strip_whitespace=True, min_length=5, max_length=3000)]
ModelName = Literal["auto", "logreg", "xgboost", "neural_mlp"]
District = Literal["Side", "Belek", "Lara", "Kemer", "Alanya", "Antalya Merkez"]
Language = Literal["tr", "en", "de", "ru"]


class PredictInput(BaseModel):
    model_config = ConfigDict(extra="forbid")
    text: Text
    model: ModelName = "auto"


class BatchInput(BaseModel):
    model_config = ConfigDict(extra="forbid")
    texts: list[Text] = Field(min_length=1, max_length=100)
    model: ModelName = "auto"


class ReviewInput(BaseModel):
    model_config = ConfigDict(extra="forbid")
    text: Text
    language: Language = "tr"
    district: District = "Side"
    occurred_on: date = Field(default_factory=date.today)
    model: ModelName = "auto"

    @field_validator("occurred_on")
    @classmethod
    def not_in_future(cls, value):
        if value > date.today():
            raise ValueError("Review date cannot be in the future.")
        return value


class StatusInput(BaseModel):
    model_config = ConfigDict(extra="forbid")
    status: Literal["new", "in_progress", "resolved"]
