"""Train every candidate; select on validation, then report the untouched test set."""

import argparse
import hashlib
import importlib.metadata
import json
import platform
import time
from datetime import datetime, timezone
from pathlib import Path

import joblib
import matplotlib
import numpy as np
import pandas as pd
from sklearn.decomposition import TruncatedSVD
from sklearn.feature_extraction.text import TfidfVectorizer
from sklearn.linear_model import LogisticRegression
from sklearn.metrics import classification_report, confusion_matrix, f1_score
from sklearn.pipeline import FeatureUnion
from sklearn.preprocessing import StandardScaler
from threadpoolctl import threadpool_limits
from xgboost import XGBClassifier

from riviera.config import LANGUAGES, ROOT, SENTIMENTS, TOPICS
from riviera.dataset import make_dataset, validate_dataset
from riviera.neural import MultiTaskMLP
from riviera.text import normalize_text

matplotlib.use("Agg")
import matplotlib.pyplot as plt


def summarize(y_sentiment, y_topic, probabilities):
    ps, pt = probabilities
    sentiment = f1_score(y_sentiment, ps.argmax(1), average="macro", zero_division=0)
    topic = f1_score(y_topic, pt.argmax(1), average="macro", zero_division=0)
    return {"sentiment_macro_f1": float(sentiment), "topic_macro_f1": float(topic),
            "mean_macro_f1": float((sentiment + topic) / 2)}


def plot_confusion(y, pred, labels, path, title):
    matrix = confusion_matrix(y, pred, labels=list(range(len(labels))))
    fig, ax = plt.subplots(figsize=(8, 6), facecolor="#f8fafc")
    ax.imshow(matrix, cmap="Blues")
    for i in range(len(labels)):
        for j in range(len(labels)):
            ax.text(j, i, str(matrix[i, j]), ha="center", va="center",
                    color="white" if matrix[i, j] > matrix.max() / 2 else "#0f172a")
    ax.set(xticks=range(len(labels)), yticks=range(len(labels)), xticklabels=labels,
           yticklabels=labels, xlabel="Predicted", ylabel="True label", title=title)
    plt.setp(ax.get_xticklabels(), rotation=35, ha="right")
    fig.tight_layout()
    fig.savefig(path, dpi=150)
    plt.close(fig)


def train(data_path=ROOT / "data/demo_reviews.csv", output=ROOT / "models",
          reports=ROOT / "reports", epochs=130):
    data_path, output, reports = Path(data_path), Path(output), Path(reports)
    output.mkdir(parents=True, exist_ok=True)
    reports.mkdir(parents=True, exist_ok=True)
    if not data_path.exists():
        data_path.parent.mkdir(parents=True, exist_ok=True)
        make_dataset().to_csv(data_path, index=False)
    df = pd.read_csv(data_path)
    validate_dataset(df)
    parts = {s: df[df.split == s].reset_index(drop=True) for s in ["train", "validation", "test"]}
    labels = {
        name: (part.sentiment.map({v: i for i, v in enumerate(SENTIMENTS)}).to_numpy(),
               part.topic.map({v: i for i, v in enumerate(TOPICS)}).to_numpy())
        for name, part in parts.items()
    }
    vectorizer = FeatureUnion([
        ("word", TfidfVectorizer(preprocessor=normalize_text, ngram_range=(1, 2),
                                min_df=2, max_features=9000, sublinear_tf=True)),
        ("char", TfidfVectorizer(preprocessor=normalize_text, analyzer="char_wb",
                                ngram_range=(3, 5), min_df=3, max_features=10000,
                                sublinear_tf=True)),
    ], transformer_weights={"word": 1.0, "char": 0.7})
    # Every learned preprocessing parameter sees TRAIN ONLY.
    with threadpool_limits(limits=1):
        sparse = {"train": vectorizer.fit_transform(parts["train"].text)}
        for name in ["validation", "test"]:
            sparse[name] = vectorizer.transform(parts[name].text)
        svd = TruncatedSVD(n_components=min(96, sparse["train"].shape[1] - 1), random_state=42)
        scaler = StandardScaler()
        dense = {"train": scaler.fit_transform(svd.fit_transform(sparse["train"])).astype("float32")}
        for name in ["validation", "test"]:
            dense[name] = np.clip(scaler.transform(svd.transform(sparse[name])), -8, 8).astype("float32")
        dense["train"] = np.clip(dense["train"], -8, 8)
        joblib.dump({"vectorizer": vectorizer, "svd": svd, "scaler": scaler},
                    output / "preprocessing.joblib", compress=3)
        candidates, elapsed = {}, {}
        for model_name in ["logreg", "xgboost"]:
            print(f"Training {model_name}...", flush=True)
            started = time.perf_counter()
            heads = []
            for target in labels["train"]:
                if model_name == "logreg":
                    head = LogisticRegression(C=4.0, max_iter=600, random_state=42)
                    head.fit(sparse["train"], target)
                else:
                    head = XGBClassifier(n_estimators=130, max_depth=4, learning_rate=0.09,
                                         subsample=0.9, colsample_bytree=0.85,
                                         objective="multi:softprob", eval_metric="mlogloss",
                                         random_state=42, n_jobs=1, tree_method="hist")
                    head.fit(dense["train"], target)
                heads.append(head)
            candidates[model_name] = heads
            elapsed[model_name] = time.perf_counter() - started
            joblib.dump(heads, output / f"{model_name}.joblib", compress=3)
        print("Training multitask neural network...", flush=True)
        started = time.perf_counter()
        neural = MultiTaskMLP(dense["train"].shape[1]).fit(
            dense["train"], *labels["train"], validation=(dense["validation"], *labels["validation"]),
            epochs=epochs)
        elapsed["neural_mlp"] = time.perf_counter() - started
        neural.save(output / "neural_mlp.npz")
        candidates["neural_mlp"] = neural

        def infer(name, part):
            x = sparse[part] if name == "logreg" else dense[part]
            model = candidates[name]
            if name == "neural_mlp":
                return model.predict_proba(x)
            return tuple(head.predict_proba(x) for head in model)

        # Select BEFORE reading test predictions.
        validation = {name: summarize(*labels["validation"], infer(name, "validation"))
                      for name in candidates}
        selected = max(validation, key=lambda n: validation[n]["mean_macro_f1"])
        metrics = {}
        for name in candidates:
            ps, pt = infer(name, "test")
            by_language = {}
            for language in LANGUAGES:
                mask = (parts["test"].language == language).to_numpy()
                by_language[language] = summarize(labels["test"][0][mask], labels["test"][1][mask],
                                                   (ps[mask], pt[mask]))
            metrics[name] = {
                "validation": validation[name], "test": summarize(*labels["test"], (ps, pt)),
                "test_by_language": by_language, "training_seconds": round(elapsed[name], 3),
                "sentiment_report": classification_report(labels["test"][0], ps.argmax(1),
                    labels=list(range(3)), target_names=SENTIMENTS, output_dict=True, zero_division=0),
                "topic_report": classification_report(labels["test"][1], pt.argmax(1),
                    labels=list(range(8)), target_names=TOPICS, output_dict=True, zero_division=0),
            }
        ps, pt = infer(selected, "test")
        plot_confusion(labels["test"][0], ps.argmax(1), SENTIMENTS, reports / "sentiment_confusion.png",
                       f"{selected} | synthetic test sentiment")
        plot_confusion(labels["test"][1], pt.argmax(1), TOPICS, reports / "topic_confusion.png",
                       f"{selected} | synthetic test topic")
    fig, ax = plt.subplots(figsize=(8, 4), facecolor="#f8fafc")
    ax.plot([h["epoch"] for h in neural.history], [h["train_loss"] for h in neural.history], label="Train")
    ax.plot([h["epoch"] for h in neural.history], [h["validation_loss"] for h in neural.history], label="Validation")
    ax.set(xlabel="Epoch", ylabel="Multi-task loss", title="Neural network learning curve")
    ax.legend()
    fig.tight_layout()
    fig.savefig(reports / "learning_curve.png", dpi=150)
    plt.close(fig)
    (reports / "neural_history.json").write_text(json.dumps(neural.history, indent=2))
    metadata = {
        "version": "1.0.0", "trained_at": datetime.now(timezone.utc).isoformat(),
        "selected_model": selected, "selection_rule": "highest mean validation macro-F1 across two tasks",
        "data_source": "synthetic" if set(df.get("source", [])) == {"ai_authored_synthetic_templates_v1"} else "user_supplied",
        "data_sha256": hashlib.sha256(data_path.read_bytes()).hexdigest(),
        "split_sizes": {name: len(part) for name, part in parts.items()},
        "classes": {"sentiment": SENTIMENTS, "topic": TOPICS}, "languages": LANGUAGES,
        "preprocessing_fit_on": "train_only", "random_seed": 42,
        "group_overlap": 0, "normalized_text_overlap": 0,
        "neural": {"hidden_layers": list(neural.hidden), "input_dim": neural.input_dim,
                   "epochs_run": len(neural.history), "best_epoch": neural.best_epoch},
        "versions": {p: importlib.metadata.version(p) for p in ["numpy", "scikit-learn", "xgboost", "scipy"]},
        "python": platform.python_version(), "metrics": metrics,
        "limitations": ["Synthetic template test scores do not estimate real-world accuracy.",
                        "Only one dominant topic and one sentiment per review.",
                        "Output scores are not calibrated probabilities.",
                        "Shared template grammar and vocabulary remain across partitions."],
    }
    for path in [output / "metadata.json", reports / "metrics.json"]:
        path.write_text(json.dumps(metadata, indent=2, ensure_ascii=False), encoding="utf-8")
    print(json.dumps({"selected_model": selected, "test": {n: v["test"] for n, v in metrics.items()}}, indent=2))
    return metadata


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--data", type=Path, default=ROOT / "data/demo_reviews.csv")
    parser.add_argument("--output", type=Path, default=ROOT / "models")
    parser.add_argument("--reports", type=Path, default=ROOT / "reports")
    parser.add_argument("--epochs", type=int, default=130)
    args = parser.parse_args()
    train(args.data, args.output, args.reports, args.epochs)


if __name__ == "__main__":
    main()
