"""Load once, batch vectorize, return auditable model outputs and explicit rules."""

import json
import time
from pathlib import Path

import joblib
import numpy as np
from threadpoolctl import threadpool_limits

from riviera.config import ACTIONS, DEPARTMENTS, ROOT, SENTIMENTS, TOPICS, TOPIC_TR
from riviera.neural import MultiTaskMLP
from riviera.text import normalize_text

MODELS = ["logreg", "xgboost", "neural_mlp"]


class ReviewEngine:
    def __init__(self, model_dir=ROOT / "models"):
        self.model_dir = Path(model_dir)
        self.metadata = json.loads((self.model_dir / "metadata.json").read_text(encoding="utf-8"))
        preprocessing = joblib.load(self.model_dir / "preprocessing.joblib")
        self.vectorizer = preprocessing["vectorizer"]
        self.svd, self.scaler = preprocessing["svd"], preprocessing["scaler"]
        self.models = {name: joblib.load(self.model_dir / f"{name}.joblib") for name in MODELS[:2]}
        self.models["neural_mlp"] = MultiTaskMLP.load(self.model_dir / "neural_mlp.npz")
        self.feature_names = self.vectorizer.get_feature_names_out()

    def predict(self, texts, model="auto", explain=False):
        selected = self.metadata["selected_model"] if model == "auto" else model
        if selected not in MODELS:
            raise ValueError("Unknown model.")
        if not texts:
            return []
        started = time.perf_counter()
        with threadpool_limits(limits=1):
            sparse = self.vectorizer.transform(texts)
            if selected == "logreg":
                ps, pt = [head.predict_proba(sparse) for head in self.models[selected]]
            else:
                dense = np.clip(self.scaler.transform(self.svd.transform(sparse)), -8, 8).astype("float32")
                if selected == "neural_mlp":
                    ps, pt = self.models[selected].predict_proba(dense)
                else:
                    ps, pt = [head.predict_proba(dense) for head in self.models[selected]]
        elapsed = (time.perf_counter() - started) * 1000 / len(texts)
        results = []
        for i, text in enumerate(texts):
            s, t = int(ps[i].argmax()), int(pt[i].argmax())
            sentiment, topic = SENTIMENTS[s], TOPICS[t]
            # A heuristic reject gate; it is not a trained OOD detector.
            tokens = normalize_text(text).split()
            word_vocab = self.vectorizer.transformer_list[0][1].vocabulary_
            coverage = sum(token.strip(".,!?;:") in word_vocab for token in tokens) / max(1, len(tokens))
            needs_review = bool(min(ps[i].max(), pt[i].max()) < 0.5 or coverage < 0.25 or sparse[i].nnz == 0)
            priority = "review" if needs_review else "high" if sentiment == "negative" else "normal" if sentiment == "neutral" else "low"
            evidence = []
            if explain and selected == "logreg" and not needs_review:
                row = sparse.getrow(i)
                contributions = row.data * self.models["logreg"][0].coef_[s, row.indices]
                order = np.argsort(contributions)[::-1]
                for index in order:
                    feature = self.feature_names[row.indices[index]]
                    if feature.startswith("word__") and contributions[index] > 0:
                        evidence.append({"ngram": feature.removeprefix("word__"),
                                         "contribution": round(float(contributions[index]), 5)})
                    if len(evidence) == 5:
                        break
            results.append({
                "sentiment": sentiment, "sentiment_score": round(float(ps[i, s]), 4),
                "sentiment_scores": {label: round(float(value), 4) for label, value in zip(SENTIMENTS, ps[i])},
                "topic": topic, "topic_label": TOPIC_TR[topic], "topic_score": round(float(pt[i, t]), 4),
                "topic_scores": {label: round(float(value), 4) for label, value in zip(TOPICS, pt[i])},
                "needs_review": needs_review, "vocabulary_coverage": round(coverage, 3),
                "priority": priority, "department": "İnsan incelemesi" if needs_review else DEPARTMENTS[topic],
                "suggested_action": "Tahmini doğrulayıp ilgili departmanı seçin." if needs_review else
                    ACTIONS[topic] if sentiment == "negative" else "Misafir geri bildirimini ilgili ekiple paylaşın.",
                "model": selected, "evidence": evidence, "latency_ms_per_item": round(elapsed, 2),
                "score_note": "Kalibre edilmemiş model skoru; doğruluk garantisi değildir.",
                "routing_note": "Departman ve öncelik, model çıktısı üzerindeki açık iş kurallarıyla belirlenir.",
            })
        return results
