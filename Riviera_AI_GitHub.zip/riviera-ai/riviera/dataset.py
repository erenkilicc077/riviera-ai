"""Deterministic AI-authored synthetic data; never represents hotel observations.

Different context wrappers of the same core sentence stay in one split.
Grammar and vocabulary still overlap: synthetic metrics are optimistic.
"""

import argparse
import hashlib
import random
from pathlib import Path

import pandas as pd

from riviera.config import LANGUAGES, ROOT, SENTIMENTS, TOPICS
from riviera.text import normalize_text

NOUNS = {
    "tr": {
        "cleanliness": ["Odanın temizliği", "Banyonun hijyeni", "Çarşafların temizliği"],
        "facilities": ["Havuz alanı", "Plajdaki olanaklar", "Tesisin yüzme havuzu"],
        "food": ["Restorandaki yemekler", "Kahvaltı büfesi", "Akşam yemeği çeşitleri"],
        "location": ["Otelin konumu", "Merkeze ulaşım", "Otelin çevresi"],
        "noise": ["Odanın ses yalıtımı", "Gece sessizliği", "Uyurken gürültü seviyesi"],
        "room": ["Odadaki klima", "Yatağın konforu", "Odanın mobilyaları"],
        "staff": ["Personelin yaklaşımı", "Resepsiyondaki hizmet", "Çalışanların ilgisi"],
        "wifi": ["İnternet bağlantısı", "Odadaki wifi", "Kablosuz ağın hızı"],
    },
    "en": {
        "cleanliness": ["The room cleanliness", "The bathroom hygiene", "The cleanliness of the sheets"],
        "facilities": ["The swimming pool area", "The beach facilities", "The hotel's pool facilities"],
        "food": ["The restaurant food", "The breakfast buffet", "The dinner selection"],
        "location": ["The hotel location", "The access to the town centre", "The hotel surroundings"],
        "noise": ["The room soundproofing", "The quietness at night", "The noise level while sleeping"],
        "room": ["The air conditioning", "The comfort of the bed", "The room furniture"],
        "staff": ["The staff attitude", "The reception service", "The attention from employees"],
        "wifi": ["The internet connection", "The wifi in the room", "The wireless network speed"],
    },
    "de": {
        "cleanliness": ["Die Sauberkeit des Zimmers", "Die Hygiene im Badezimmer", "Die Sauberkeit der Bettwäsche"],
        "facilities": ["Der Zustand des Pools", "Der Zustand der Strandanlagen", "Der Swimmingpool im Hotel"],
        "food": ["Das Essen im Restaurant", "Das Frühstücksbuffet", "Die Auswahl beim Abendessen"],
        "location": ["Die Lage des Hotels", "Die Anbindung an das Zentrum", "Die Umgebung des Hotels"],
        "noise": ["Die Schalldämmung des Zimmers", "Die Ruhe in der Nacht", "Der Lärmschutz beim Schlafen"],
        "room": ["Die Klimaanlage im Zimmer", "Der Komfort des Bettes", "Die Einrichtung des Zimmers"],
        "staff": ["Die Freundlichkeit des Personals", "Der Service an der Rezeption", "Die Aufmerksamkeit der Mitarbeiter"],
        "wifi": ["Die Internetverbindung", "Das WLAN im Zimmer", "Die Geschwindigkeit des drahtlosen Netzes"],
    },
    "ru": {
        "cleanliness": ["Чистота номера", "Гигиена в ванной", "Чистота постельного белья"],
        "facilities": ["Территория бассейна", "Инфраструктура пляжа", "Бассейн в отеле"],
        "food": ["Еда в ресторане", "Завтрак в отеле", "Выбор блюд на ужин"],
        "location": ["Расположение отеля", "Доступность центра города", "Территория вокруг отеля"],
        "noise": ["Звукоизоляция номера", "Тишина ночью", "Защита от шума во время сна"],
        "room": ["Работа кондиционера", "Удобство кровати", "Мебель в номере"],
        "staff": ["Работа персонала", "Обслуживание на ресепшене", "Отношение сотрудников"],
        "wifi": ["Интернет в отеле", "Вайфай в номере", "Скорость беспроводной сети"],
    },
}

OPINIONS = {
    "tr": {
        "negative": ["çok kötüydü", "hayal kırıklığı yarattı", "beklentimizin çok altındaydı", "hiç iyi değildi", "maalesef berbattı", "yetersizdi ve memnun kalmadık", "ciddi şekilde sorunluydu", "iyileştirilmesi gerekiyor"],
        "neutral": ["ortalama düzeydeydi", "ne iyi ne kötüydü", "standart seviyedeydi", "idare ederdi", "sıradandı", "kabul edilebilir düzeydeydi", "beklediğimiz gibiydi", "fena değildi ama özel de değildi"],
        "positive": ["çok iyiydi", "kusursuzdu", "beklentimizin üzerindeydi", "harikaydı ve çok memnun kaldık", "gerçekten mükemmeldi", "oldukça başarılıydı", "bizi çok mutlu etti", "tavsiye edebileceğimiz kadar güzeldi"],
    },
    "en": {
        "negative": ["was very poor", "was disappointing", "was far below expectations", "was not good at all", "was unfortunately terrible", "was inadequate and left us unhappy", "had serious problems", "needs considerable improvement"],
        "neutral": ["was average", "was neither good nor bad", "was fairly standard", "was just acceptable", "was ordinary", "was adequate", "was as expected", "was okay but nothing special"],
        "positive": ["was very good", "was excellent", "exceeded our expectations", "was wonderful and made us happy", "was absolutely perfect", "was impressive", "was delightful", "was great and worth recommending"],
    },
    "de": {
        "negative": ["war sehr schlecht", "war enttäuschend", "lag weit unter unseren Erwartungen", "war überhaupt nicht gut", "war leider schrecklich", "war unzureichend und machte uns unzufrieden", "hatte erhebliche Probleme", "muss dringend verbessert werden"],
        "neutral": ["war durchschnittlich", "war weder gut noch schlecht", "war ziemlich normal", "war gerade akzeptabel", "war gewöhnlich", "war ausreichend", "war wie erwartet", "war in Ordnung aber nichts Besonderes"],
        "positive": ["war sehr gut", "war ausgezeichnet", "übertraf unsere Erwartungen", "war wunderbar und machte uns glücklich", "war wirklich perfekt", "war beeindruckend", "war erfreulich", "war großartig und empfehlenswert"],
    },
    "ru": {
        "negative": ["нас очень разочаровало", "оставляет плохое впечатление", "оказалось намного хуже ожиданий", "совсем не понравилось", "было просто ужасным", "было недостаточным и вызвало недовольство", "имело серьёзные проблемы", "требует значительного улучшения"],
        "neutral": ["было на среднем уровне", "не было ни хорошим ни плохим", "было вполне стандартным", "было просто приемлемым", "было обычным", "было удовлетворительным", "было как ожидалось", "было неплохим но ничем не выделялось"],
        "positive": ["нам очень понравилось", "было превосходным", "превзошло наши ожидания", "было замечательным и нас порадовало", "было действительно идеальным", "произвело отличное впечатление", "доставило большое удовольствие", "было отличным и заслуживает рекомендации"],
    },
}

CONTEXTS = {
    "tr": [("Tatilimiz boyunca", "Bu bizim aile tatilimizdi."), ("Bu konaklamada", "Antalya'da bir hafta kaldık.")],
    "en": [("During our holiday,", "We travelled as a family."), ("During this stay,", "We spent a week in Antalya.")],
    "de": [("Während unseres Urlaubs:", "Wir waren als Familie unterwegs."), ("Bei diesem Aufenthalt:", "Wir waren eine Woche in Antalya.")],
    "ru": [("Во время отпуска:", "Мы приехали всей семьёй."), ("Во время проживания:", "Мы провели неделю в Анталье.")],
}


def make_dataset(seed: int = 42) -> pd.DataFrame:
    rng = random.Random(seed)
    rows = []
    for language in LANGUAGES:
        for topic in TOPICS:
            for sentiment in SENTIMENTS:
                combinations = [(a, b) for a in range(3) for b in range(8)]
                rng.shuffle(combinations)
                for index, (noun_index, opinion_index) in enumerate(combinations):
                    split = "train" if index < 16 else "validation" if index < 20 else "test"
                    group = f"{language}:{topic}:{sentiment}:{noun_index}:{opinion_index}"
                    core = f"{NOUNS[language][topic][noun_index]} {OPINIONS[language][sentiment][opinion_index]}."
                    for wrapper, (prefix, suffix) in enumerate(CONTEXTS[language]):
                        rows.append({
                            "review_id": hashlib.sha256(f"{group}:{wrapper}".encode()).hexdigest()[:16],
                            "text": f"{prefix} {core} {suffix}", "language": language,
                            "sentiment": sentiment, "topic": topic, "group_id": group,
                            "split": split, "source": "ai_authored_synthetic_templates_v1",
                        })
    return pd.DataFrame(rows).sample(frac=1, random_state=seed).reset_index(drop=True)


def validate_dataset(df: pd.DataFrame) -> None:
    required = {"text", "language", "sentiment", "topic", "group_id", "split"}
    if not required.issubset(df.columns):
        raise ValueError(f"Missing columns: {sorted(required - set(df.columns))}")
    if df[list(required)].isna().any().any() or df.empty:
        raise ValueError("Dataset must be nonempty and required values cannot be null.")
    for column, valid in [("language", LANGUAGES), ("sentiment", SENTIMENTS), ("topic", TOPICS),
                          ("split", ["train", "validation", "test"])]:
        if not set(df[column]).issubset(valid):
            raise ValueError(f"Unknown {column} label.")
    if (df.groupby("group_id")["split"].nunique() > 1).any():
        raise ValueError("Group leakage: a group appears in multiple splits.")
    checked = df.assign(clean_text=df["text"].map(normalize_text))
    if checked["clean_text"].str.len().lt(5).any():
        raise ValueError("Texts must contain at least five characters.")
    if (checked.groupby("clean_text")["split"].nunique() > 1).any():
        raise ValueError("Text leakage: the same normalized text appears in multiple splits.")
    for split in ["train", "validation", "test"]:
        part = df[df["split"] == split]
        for column, expected in [("sentiment", SENTIMENTS), ("topic", TOPICS), ("language", LANGUAGES)]:
            if set(part[column]) != set(expected):
                raise ValueError(f"{split} does not cover all {column} classes.")


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--output", type=Path, default=ROOT / "data/demo_reviews.csv")
    args = parser.parse_args()
    df = make_dataset()
    validate_dataset(df)
    args.output.parent.mkdir(parents=True, exist_ok=True)
    df.to_csv(args.output, index=False)
    print(f"Saved {len(df)} synthetic reviews to {args.output}")


if __name__ == "__main__":
    main()
