"""FastAPI delivery layer. No model training or business rules in route handlers."""

import csv
import io
import os
from contextlib import asynccontextmanager
from pathlib import Path
from typing import Literal

from fastapi import FastAPI, HTTPException, Query, Request
from fastapi.responses import FileResponse, JSONResponse, Response
from fastapi.staticfiles import StaticFiles

from riviera import __version__
from riviera.config import DISTRICTS, ROOT, TOPIC_TR
from riviera.inference import ReviewEngine
from riviera.schemas import BatchInput, PredictInput, ReviewInput, StatusInput
from riviera.service import add_reviews, parse_csv
from riviera.store import ReviewStore


def create_app(db_path=None, model_dir=None):
    @asynccontextmanager
    async def lifespan(app):
        app.state.store = ReviewStore(db_path or os.getenv("RIVIERA_DB_PATH", ROOT / "runtime/reviews.sqlite"))
        try:
            app.state.engine = ReviewEngine(model_dir or ROOT / "models")
        except FileNotFoundError:
            app.state.engine = None
        yield

    app = FastAPI(title="Riviera AI", version=__version__, lifespan=lifespan,
                  description="Multilingual hotel review NLP demo. Model scores are uncalibrated.")

    @app.middleware("http")
    async def body_limit(request: Request, call_next):
        if request.method in {"POST", "PUT", "PATCH"}:
            size = request.headers.get("content-length")
            if size and (not size.isdigit() or int(size) > 1024 * 1024):
                return JSONResponse({"detail": "Body exceeds 1 MiB or has invalid length."}, status_code=413)
            if len(await request.body()) > 1024 * 1024:
                return JSONResponse({"detail": "Body exceeds 1 MiB."}, status_code=413)
        response = await call_next(request)
        response.headers["X-Content-Type-Options"] = "nosniff"
        response.headers["Referrer-Policy"] = "same-origin"
        return response

    def engine():
        if app.state.engine is None:
            raise HTTPException(503, "Models missing. Run: python -m riviera.train")
        return app.state.engine

    def validate_district(value):
        if value and value not in DISTRICTS:
            raise HTTPException(422, "Unknown district.")

    @app.get("/api/health")
    def health():
        ready = app.state.engine is not None
        return {"status": "ok" if ready else "models_missing", "models_ready": ready, "version": __version__}

    @app.get("/api/models")
    def models():
        return engine().metadata

    @app.post("/api/predict")
    def predict(body: PredictInput):
        return engine().predict([body.text], model=body.model, explain=True)[0]

    @app.post("/api/predict/batch")
    def predict_batch(body: BatchInput):
        return {"items": engine().predict(body.texts, model=body.model)}

    @app.post("/api/reviews", status_code=201)
    def create_review(body: ReviewInput):
        result = add_reviews(app.state.store, engine(), [body])
        if result["duplicates"]:
            raise HTTPException(409, "This review already exists for this district, language and date.")
        return app.state.store.get(result["ids"][0])

    @app.post("/api/reviews/import")
    async def import_reviews(request: Request):
        try:
            items = parse_csv(await request.body())
        except ValueError as exc:
            raise HTTPException(422, str(exc)) from exc
        return add_reviews(app.state.store, engine(), items, source="csv_import")

    @app.get("/api/reviews")
    def reviews(district: str | None = None,
                sentiment: Literal["negative", "neutral", "positive"] | None = None,
                status: Literal["new", "in_progress", "resolved"] | None = None,
                days: int = Query(30, ge=1, le=3650), limit: int = Query(100, ge=1, le=500),
                offset: int = Query(0, ge=0)):
        validate_district(district)
        return app.state.store.list(district, sentiment, status, days, limit, offset)

    @app.patch("/api/reviews/{review_id}/status")
    def update_status(review_id: str, body: StatusInput):
        if not app.state.store.update_status(review_id, body.status):
            raise HTTPException(404, "Review not found.")
        return app.state.store.get(review_id)

    @app.get("/api/dashboard")
    def dashboard(district: str | None = None, days: int = Query(30, ge=1, le=3650)):
        validate_district(district)
        return {**app.state.store.dashboard(district, days), "topic_labels": TOPIC_TR}

    @app.get("/api/export")
    def export(district: str | None = None, days: int = Query(30, ge=1, le=3650)):
        validate_district(district)
        result = app.state.store.list(district=district, days=days, limit=10000)
        if result["total"] > 10000:
            raise HTTPException(422, "Export is limited to 10000 rows. Narrow the date or district filter.")
        rows = result["items"]
        stream = io.StringIO(newline="")
        fields = ["text", "language", "district", "occurred_on", "sentiment", "topic", "needs_review", "status", "source"]
        writer = csv.DictWriter(stream, fieldnames=fields, extrasaction="ignore")
        writer.writeheader()
        for row in rows:
            # Spreadsheet formula injection protection on every exported cell.
            clean = {}
            for key in fields:
                value = str(row[key])
                clean[key] = "'" + value if value.lstrip().startswith(("=", "+", "-", "@")) else value
            writer.writerow(clean)
        return Response(content=("\ufeff" + stream.getvalue()).encode("utf-8"), media_type="text/csv; charset=utf-8",
                        headers={"Content-Disposition": 'attachment; filename="riviera-reviews.csv"'})

    @app.get("/")
    def index():
        return FileResponse(Path(__file__).parent / "web/index.html")

    app.mount("/static", StaticFiles(directory=Path(__file__).parent / "web"), name="static")
    return app


app = create_app()
