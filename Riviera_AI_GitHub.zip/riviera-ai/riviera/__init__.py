"""Riviera AI: a reproducible hotel NLP portfolio project."""

__version__ = "1.0.0"
