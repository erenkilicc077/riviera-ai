"""Application service: models suggest; the operation team decides."""

import csv
import io

import pandas as pd
from pydantic import ValidationError

from riviera.config import DISTRICTS, ROOT
from riviera.schemas import ReviewInput


def add_reviews(store, engine, reviews, source="manual"):
    # Every row has already passed schema validation. A single DB transaction saves the batch.
    groups = {}
    for i, item in enumerate(reviews):
        groups.setdefault(item.model, []).append((i, item))
    predictions = [None] * len(reviews)
    for model, items in groups.items():
        values = engine.predict([item.text for _, item in items], model=model)
        for (index, _), prediction in zip(items, values):
            predictions[index] = prediction
    return store.add_many([(item.model_dump(), prediction, source)
                           for item, prediction in zip(reviews, predictions)])


def parse_csv(raw: bytes):
    if len(raw) > 1024 * 1024:
        raise ValueError("CSV must be smaller than 1 MiB.")
    try:
        content = raw.decode("utf-8-sig")
    except UnicodeDecodeError as exc:
        raise ValueError("CSV must use UTF-8 encoding.") from exc
    reader = csv.DictReader(io.StringIO(content))
    required = {"text", "language", "district"}
    if not reader.fieldnames or not required.issubset(reader.fieldnames):
        raise ValueError("CSV needs text, language and district columns. Optional: occurred_on.")
    if len(reader.fieldnames) != len(set(reader.fieldnames)):
        raise ValueError("Duplicate CSV column names are not allowed.")
    allowed = required | {"occurred_on"}
    if set(reader.fieldnames) - allowed:
        raise ValueError("Unexpected CSV columns. Use the supplied template.")
    items = []
    try:
        for index, row in enumerate(reader, start=2):
            if len(items) >= 500:
                raise ValueError("Import is limited to 500 reviews per request.")
            if None in row:
                raise ValueError(f"Row {index} has extra cells.")
            if any(not (row.get(key) or "").strip() for key in required):
                raise ValueError(f"Missing required value at row {index}.")
            clean = {key: value for key, value in row.items() if value not in (None, "")}
            try:
                items.append(ReviewInput(**clean))
            except ValidationError as exc:
                raise ValueError(f"Invalid review at row {index}: {exc.errors()[0]['msg']}") from exc
    except csv.Error as exc:
        raise ValueError("Malformed CSV.") from exc
    if not items:
        raise ValueError("CSV contains no review rows.")
    return items


def seed_demo(store, engine):
    from datetime import date, timedelta

    df = pd.read_csv(ROOT / "data/demo_reviews.csv")
    test = df[df.split == "test"]
    # Ground-truth labels only control demo sampling. All displayed labels are model predictions.
    selected = pd.concat([test[test.sentiment == s].sample(n=n, random_state=42)
                          for s, n in [("negative", 48), ("neutral", 24), ("positive", 24)]])
    selected = selected.sample(frac=1, random_state=42).reset_index(drop=True)
    inputs = [ReviewInput(text=row.text, language=row.language, district=DISTRICTS[i % len(DISTRICTS)],
                          occurred_on=date.today() - timedelta(days=i % 21))
              for i, row in selected.iterrows()]
    return add_reviews(store, engine, inputs, source="synthetic_demo")
