import csv
import io

import pytest
from fastapi.testclient import TestClient

from riviera.api import create_app


@pytest.fixture
def client(tmp_path):
    with TestClient(create_app(db_path=tmp_path / "reviews.sqlite")) as value:
        yield value


def payload(**changes):
    return {"text": "Odadaki wifi çok kötüydü ve bağlantı sürekli kopuyordu.",
            "language": "tr", "district": "Side", **changes}


def test_health_and_real_predictions_from_all_models(client):
    assert client.get("/api/health").json()["models_ready"]
    for model in ["logreg", "xgboost", "neural_mlp"]:
        response = client.post("/api/predict", json={"text": payload()["text"], "model": model})
        assert response.status_code == 200
        output = response.json()
        assert output["model"] == model
        assert abs(sum(output["sentiment_scores"].values()) - 1) < 0.001
        assert 0 <= output["topic_score"] <= 1


def test_persistence_duplicate_guard_filters_and_resolution(client):
    first = client.post("/api/reviews", json=payload())
    assert first.status_code == 201
    review_id = first.json()["id"]
    assert client.post("/api/reviews", json=payload()).status_code == 409
    assert client.get("/api/reviews?district=Belek").json()["total"] == 0
    assert client.get("/api/reviews?district=Side").json()["total"] == 1
    assert client.get("/api/dashboard").json()["summary"]["open_issues"] == 1
    response = client.patch(f"/api/reviews/{review_id}/status", json={"status": "resolved"})
    assert response.status_code == 200
    assert client.get("/api/dashboard").json()["summary"]["open_issues"] == 0


def test_invalid_inputs_and_unknown_record(client):
    assert client.post("/api/predict", json={"text": "x"}).status_code == 422
    assert client.post("/api/predict", json={"text": "A valid review", "model": "madeup"}).status_code == 422
    assert client.post("/api/reviews", json=payload(district="unknown")).status_code == 422
    assert client.post("/api/reviews", json=payload(occurred_on="2099-01-01")).status_code == 422
    assert client.patch("/api/reviews/no-such-id/status", json={"status": "resolved"}).status_code == 404
    assert client.get("/api/dashboard?district=unknown").status_code == 422


def test_unfamiliar_text_requests_human_review(client):
    result = client.post("/api/predict", json={"text": "量子力学和星际旅行研究"}).json()
    assert result["needs_review"] is True
    assert result["priority"] == "review"
    assert result["department"] == "İnsan incelemesi"


def test_batch_import_is_atomic_and_idempotent(client):
    valid = b'text,language,district\n"The breakfast buffet was excellent.",en,Belek\n'
    invalid = valid + b'"The room was dirty.",xx,Side\n'
    assert client.post("/api/reviews/import", content=invalid).status_code == 422
    assert client.get("/api/reviews").json()["total"] == 0
    result = client.post("/api/reviews/import", content=valid).json()
    assert result["inserted"] == 1
    repeated = client.post("/api/reviews/import", content=valid).json()
    assert repeated["duplicates"] == 1


def test_export_neutralizes_spreadsheet_formulas_and_has_utf8_bom(client):
    client.post("/api/reviews", json=payload(text="=HYPERLINK evil example room wifi"))
    response = client.get("/api/export")
    assert response.content.startswith(b"\xef\xbb\xbf")
    rows = list(csv.DictReader(io.StringIO(response.content.decode("utf-8-sig"))))
    assert rows[0]["text"].startswith("'=")


def test_empty_dashboard_has_no_invented_statistics(client):
    summary = client.get("/api/dashboard").json()["summary"]
    assert summary["total"] == 0
    assert summary["negative_rate"] is None


def test_pagination_and_batch_prediction_limits(client):
    assert client.post("/api/predict/batch", json={"texts": []}).status_code == 422
    result = client.post("/api/predict/batch", json={"texts": [payload()["text"], "The staff service was excellent."]}).json()
    assert len(result["items"]) == 2
    assert client.get("/api/reviews?limit=501").status_code == 422


def test_missing_models_returns_actionable_503(tmp_path):
    with TestClient(create_app(db_path=tmp_path / "empty.sqlite", model_dir=tmp_path / "missing")) as client:
        assert not client.get("/api/health").json()["models_ready"]
        assert client.post("/api/predict", json={"text": payload()["text"]}).status_code == 503
