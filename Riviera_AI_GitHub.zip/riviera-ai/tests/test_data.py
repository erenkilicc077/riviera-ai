import pandas as pd
import pytest

from riviera.dataset import make_dataset, validate_dataset
from riviera.service import parse_csv
from riviera.text import normalize_text


def test_generated_dataset_is_reproducible_and_split_safe():
    first, second = make_dataset(), make_dataset()
    pd.testing.assert_frame_equal(first, second)
    assert len(first) == 4608
    validate_dataset(first)
    assert first.groupby("group_id").split.nunique().max() == 1


def test_leaking_sentence_context_is_rejected():
    data = make_dataset()
    index = data.index[data.split == "train"][0]
    duplicate = data.loc[[index]].copy()
    duplicate["split"] = "test"
    with pytest.raises(ValueError, match="leakage"):
        validate_dataset(pd.concat([data, duplicate]))


def test_normalized_text_overlap_is_rejected_even_with_different_group():
    data = make_dataset()
    duplicate = data.iloc[[0]].copy()
    duplicate["text"] = "  " + duplicate["text"].iloc[0].upper() + "  "
    duplicate["group_id"] = "different"
    duplicate["split"] = "test" if duplicate["split"].iloc[0] == "train" else "train"
    with pytest.raises(ValueError, match="Text leakage"):
        validate_dataset(pd.concat([data, duplicate]))


def test_cleaning_preserves_negation_and_unicode():
    assert "değil" in normalize_text("TEMİZ DEĞİL")
    assert "nicht" in normalize_text("NICHT GUT")
    assert "плохо" in normalize_text("ПЛОХО")
    assert "@" not in normalize_text("contact me at hello@example.com")


def test_csv_validates_whole_file_before_import():
    raw = 'text,language,district\n"The food was excellent.",en,Side\n"Bad wifi connection.",xx,Side\n'.encode()
    with pytest.raises(ValueError, match="row 3"):
        parse_csv(raw)


def test_csv_missing_required_cell_is_rejected():
    # Missing language must not quietly use the API's default language.
    with pytest.raises(ValueError):
        parse_csv(b'text,language,district\n"The food was excellent.",,Side\n')
