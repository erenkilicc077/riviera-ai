import numpy as np

from riviera.neural import MultiTaskMLP


def test_backprop_matches_numerical_gradient():
    model = MultiTaskMLP(3, hidden=(4, 3), n_sentiments=3, n_topics=2, seed=7)
    model.params = {key: value.astype("float64") for key, value in model.params.items()}
    x = np.array([[0.2, 0.7, -0.3], [-0.4, 0.8, 0.9]], dtype="float64")
    ys, yt = np.array([0, 2]), np.array([1, 0])
    _, gradients = model.loss_and_grad(x, ys, yt)
    epsilon = 1e-6
    for key, index in [("W1", (1, 1)), ("b1", (2,)), ("W2", (2, 1)),
                       ("b2", (1,)), ("Ws", (0, 2)), ("bs", (2,)),
                       ("Wt", (1, 0)), ("bt", (1,))]:
        original = model.params[key][index]
        model.params[key][index] = original + epsilon
        plus, _ = model.loss_and_grad(x, ys, yt)
        model.params[key][index] = original - epsilon
        minus, _ = model.loss_and_grad(x, ys, yt)
        model.params[key][index] = original
        numerical = (plus - minus) / (2 * epsilon)
        np.testing.assert_allclose(gradients[key][index], numerical, rtol=2e-4, atol=1e-7)


def test_network_learns_and_npz_roundtrip_is_exact(tmp_path):
    rng = np.random.default_rng(3)
    x = rng.normal(size=(180, 3)).astype("float32")
    ys = (x[:, 0] > 0).astype(int)
    yt = (x[:, 1] > 0).astype(int)
    model = MultiTaskMLP(3, hidden=(12, 8), n_sentiments=2, n_topics=2)
    before, _ = model.loss_and_grad(x, ys, yt)
    model.fit(x, ys, yt, validation=(x, ys, yt), epochs=60, batch_size=60, lr=0.01)
    after, _ = model.loss_and_grad(x, ys, yt)
    assert after < before * 0.3
    model.save(tmp_path / "network.npz")
    restored = MultiTaskMLP.load(tmp_path / "network.npz")
    for expected, actual in zip(model.predict_proba(x), restored.predict_proba(x)):
        np.testing.assert_array_equal(expected, actual)
